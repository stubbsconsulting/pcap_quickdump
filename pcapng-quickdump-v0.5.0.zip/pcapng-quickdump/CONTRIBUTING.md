# Contributing

Near-term focus areas:

1. Additional Kerberos fields and edge cases
2. CSV and JSON reports
3. Optional classic `.pcap` support
4. Unit tests with sanitized fixtures
