
#!/usr/bin/env python3
"""pcapng_quickdump.py - standalone PCAPNG quick dissector/report generator.

No Wireshark/TShark/libpcap/third-party packages.
Adds lightweight Kerberos decoding for UDP/TCP 88: message type, SPNs, realms, and KDC error codes.
"""
import argparse, datetime as dt, ipaddress, os, struct, sys
from collections import Counter, defaultdict

SHB=0x0A0D0D0A; IDB=1; SPB=3; EPB=6
LINKTYPE_ETHERNET=1; LINKTYPE_LINUX_SLL=113; LINKTYPE_LINUX_SLL2=276
PROTO={1:'ICMP',2:'IGMP',6:'TCP',17:'UDP',41:'IPv6',47:'GRE',50:'ESP',51:'AH',58:'ICMPv6',89:'OSPF'}
KRB_MSG={10:'AS-REQ',11:'AS-REP',12:'TGS-REQ',13:'TGS-REP',14:'AP-REQ',15:'AP-REP',20:'KRB-SAFE',21:'KRB-PRIV',22:'KRB-CRED',30:'KRB-ERROR'}
KRB_ERR={0:'KDC_ERR_NONE',1:'KDC_ERR_NAME_EXP',2:'KDC_ERR_SERVICE_EXP',3:'KDC_ERR_BAD_PVNO',4:'KDC_ERR_C_OLD_MAST_KVNO',5:'KDC_ERR_S_OLD_MAST_KVNO',6:'KDC_ERR_C_PRINCIPAL_UNKNOWN',7:'KDC_ERR_S_PRINCIPAL_UNKNOWN',8:'KDC_ERR_PRINCIPAL_NOT_UNIQUE',9:'KDC_ERR_NULL_KEY',10:'KDC_ERR_CANNOT_POSTDATE',11:'KDC_ERR_NEVER_VALID',12:'KDC_ERR_POLICY',13:'KDC_ERR_BADOPTION',14:'KDC_ERR_ETYPE_NOSUPP',15:'KDC_ERR_SUMTYPE_NOSUPP',16:'KDC_ERR_PADATA_TYPE_NOSUPP',17:'KDC_ERR_TRTYPE_NOSUPP',18:'KDC_ERR_CLIENT_REVOKED',19:'KDC_ERR_SERVICE_REVOKED',20:'KDC_ERR_TGT_REVOKED',21:'KDC_ERR_CLIENT_NOTYET',22:'KDC_ERR_SERVICE_NOTYET',23:'KDC_ERR_KEY_EXPIRED',24:'KDC_ERR_PREAUTH_FAILED',25:'KDC_ERR_PREAUTH_REQUIRED',26:'KDC_ERR_SERVER_NOMATCH',31:'KRB_AP_ERR_BAD_INTEGRITY',32:'KRB_AP_ERR_TKT_EXPIRED',33:'KRB_AP_ERR_TKT_NYV',34:'KRB_AP_ERR_REPEAT',35:'KRB_AP_ERR_NOT_US',36:'KRB_AP_ERR_BADMATCH',37:'KRB_AP_ERR_SKEW',38:'KRB_AP_ERR_BADADDR',39:'KRB_AP_ERR_BADVERSION',40:'KRB_AP_ERR_MSG_TYPE',41:'KRB_AP_ERR_MODIFIED',42:'KRB_AP_ERR_BADORDER',44:'KRB_AP_ERR_BADKEYVER',45:'KRB_AP_ERR_NOKEY',46:'KRB_AP_ERR_MUT_FAIL',47:'KRB_AP_ERR_BADDIRECTION',48:'KRB_AP_ERR_METHOD',49:'KRB_AP_ERR_BADSEQ',50:'KRB_AP_ERR_INAPP_CKSUM',52:'KRB_ERR_RESPONSE_TOO_BIG'}

# ----------------------------- low level helpers -----------------------------
def u16(d,o,e): return struct.unpack_from(e+'H',d,o)[0]
def u32(d,o,e): return struct.unpack_from(e+'I',d,o)[0]
def mac(b): return ':'.join(f'{x:02x}' for x in b)
def ip4(b): return '.'.join(map(str,b))
def ip6(b): return str(ipaddress.IPv6Address(b))
def fmt_ts(t):
    if t is None: return 'n/a'
    try: return dt.datetime.fromtimestamp(t, tz=dt.timezone.utc).isoformat()
    except Exception: return f'{t:.6f}'
def ascii_preview(data,n=160):
    b=data[:n]; s=''.join(chr(x) if 32<=x<=126 else '.' for x in b)
    return s if len(data)<=n else s+f'... +{len(data)-n} bytes'
def hex_preview(data,n=96):
    b=data[:n]; hp=' '.join(f'{x:02x}' for x in b); ap=''.join(chr(x) if 32<=x<=126 else '.' for x in b)
    if len(data)>n: ap += f' ... +{len(data)-n} bytes'
    return hp, ap

# ----------------------------- PCAPNG reader -----------------------------
def parse_options(body, off, endian):
    opts={}
    while off+4<=len(body):
        code=u16(body,off,endian); ln=u16(body,off+2,endian); off+=4
        if code==0: break
        opts.setdefault(code,[]).append(body[off:off+ln]); off += (ln+3)&~3
    return opts

def tsresol(opts):
    vals=opts.get(9)
    if vals and vals[0]:
        v=vals[0][0]; return 2**-(v&0x7F) if v&0x80 else 10**-v
    return 1e-6

class PcapngReader:
    def __init__(self,path):
        self.path=path; self.data=open(path,'rb').read(); self.off=0; self.endian='<'; self.interfaces=[]
    def _choose_shb(self):
        if self.off+12>len(self.data): return None
        for endian,blen in (('<',struct.unpack_from('<I',self.data,self.off+4)[0]),('>',struct.unpack_from('>I',self.data,self.off+4)[0])):
            if blen>=28 and self.off+blen<=len(self.data) and struct.unpack_from(endian+'I',self.data,self.off+8)[0]==0x1A2B3C4D: return endian,blen
        return None
    def blocks(self):
        while self.off+12<=len(self.data):
            if struct.unpack_from('<I',self.data,self.off)[0]==SHB:
                c=self._choose_shb();
                if not c: raise ValueError(f'Invalid Section Header Block at offset {self.off}')
                self.endian,blen=c; btype=SHB
            else:
                btype=u32(self.data,self.off,self.endian); blen=u32(self.data,self.off+4,self.endian)
            if blen<12 or self.off+blen>len(self.data): raise ValueError(f'Invalid block length {blen} at offset {self.off}')
            body=self.data[self.off+8:self.off+blen-4]; cur=self.off; self.off+=blen
            yield btype,body,cur,blen
    def read_packets(self):
        frame=0
        for btype,body,file_off,blen in self.blocks():
            if btype==SHB: self.interfaces=[]; continue
            if btype==IDB:
                if len(body)<8: continue
                opts=parse_options(body,8,self.endian); name=opts.get(2,[b''])[0].decode('utf-8','replace').rstrip('\x00') if 2 in opts else ''
                self.interfaces.append({'linktype':u16(body,0,self.endian),'snaplen':u32(body,4,self.endian),'tsresol':tsresol(opts),'name':name}); continue
            if btype==EPB and len(body)>=20:
                iface_id=u32(body,0,self.endian); ts_hi=u32(body,4,self.endian); ts_lo=u32(body,8,self.endian); caplen=u32(body,12,self.endian); origlen=u32(body,16,self.endian)
                pkt=body[20:20+caplen]; iface=self.interfaces[iface_id] if iface_id<len(self.interfaces) else {'linktype':LINKTYPE_ETHERNET,'tsresol':1e-6,'name':'','snaplen':0}
                frame+=1; yield {'frame':frame,'ts':((ts_hi<<32)|ts_lo)*iface.get('tsresol',1e-6),'iface_id':iface_id,'iface':iface,'caplen':caplen,'origlen':origlen,'data':pkt,'file_off':file_off}
            elif btype==SPB and len(body)>=4:
                origlen=u32(body,0,self.endian); pkt=body[4:4+origlen]; iface=self.interfaces[0] if self.interfaces else {'linktype':LINKTYPE_ETHERNET,'tsresol':1e-6,'name':'','snaplen':0}
                frame+=1; yield {'frame':frame,'ts':None,'iface_id':0,'iface':iface,'caplen':len(pkt),'origlen':origlen,'data':pkt,'file_off':file_off}

# ----------------------------- ASN.1 / Kerberos -----------------------------
def asn1_tlv(data, off=0):
    if off>=len(data): return None
    start=off; first=data[off]; off+=1; cls=first>>6; cons=bool(first&0x20); tag=first&0x1f
    if tag==0x1f:
        tag=0
        while off<len(data):
            b=data[off]; off+=1; tag=(tag<<7)|(b&0x7f)
            if not (b&0x80): break
    if off>=len(data): return None
    lb=data[off]; off+=1
    if lb&0x80:
        n=lb&0x7f
        if n==0 or off+n>len(data): return None
        ln=int.from_bytes(data[off:off+n],'big'); off+=n
    else: ln=lb
    if off+ln>len(data): return None
    return {'cls':cls,'cons':cons,'tag':tag,'start':start,'hdr':off-start,'vstart':off,'len':ln,'vend':off+ln,'value':data[off:off+ln],'next':off+ln}

def asn1_children(value):
    out=[]; off=0
    while off<len(value):
        t=asn1_tlv(value,off)
        if not t or t['next']<=off: break
        out.append(t); off=t['next']
    return out

def child_by_ctx(children, tag):
    for c in children:
        if c['cls']==2 and c['tag']==tag: return c
    return None

def unwrap_seq(t):
    ch=asn1_children(t['value'])
    if len(ch)==1 and ch[0]['cls']==0 and ch[0]['tag']==16: return asn1_children(ch[0]['value'])
    return ch

def int_from_tlv(t):
    if not t: return None
    ch=asn1_children(t['value']) if t['cls']==2 else [t]
    for c in ch:
        if c['cls']==0 and c['tag']==2:
            return int.from_bytes(c['value'],'big',signed=bool(c['value'] and c['value'][0]&0x80))
    return None

def string_from_tlv(t):
    if not t: return None
    ch=asn1_children(t['value']) if t['cls']==2 else [t]
    for c in ch:
        if c['cls']==0 and c['tag'] in (12,19,26,27,28,30):
            return c['value'].decode('utf-8','replace')
    return None

def strings_under(t):
    vals=[]
    def walk(x):
        ch=asn1_children(x['value']) if x['cons'] else []
        if x['cls']==0 and x['tag'] in (12,19,26,27,28,30): vals.append(x['value'].decode('utf-8','replace'))
        for y in ch: walk(y)
    walk(t); return vals

def principal_from_tlv(t, realm=None):
    if not t: return None
    names=[]
    ch=unwrap_seq(t)
    ns=child_by_ctx(ch,1)
    if ns: names=strings_under(ns)
    else: names=strings_under(t)
    if not names: return None
    spn='/'.join(names)
    return f'{spn}@{realm}' if realm else spn

def kerberos_payload(payload, is_tcp=False):
    # Kerberos over TCP has a 4-byte big-endian record length.
    if len(payload)>=5:
        ln=int.from_bytes(payload[:4],'big')
        if ln==len(payload)-4 or (0<ln<=len(payload)-4): payload=payload[4:4+ln]
    return payload

def parse_kerberos(payload):
    data=kerberos_payload(payload)
    t=asn1_tlv(data,0)
    if not t or t['cls']!=1: return None
    app=t['tag']; msg=KRB_MSG.get(app,f'KRB-MSG-{app}')
    top=unwrap_seq(t)
    parts=[f'Kerberos {msg} msg_type={app}']
    if app in (10,12):
        body=child_by_ctx(top,4)
        if body:
            bch=unwrap_seq(body); realm=string_from_tlv(child_by_ctx(bch,2)); cname=principal_from_tlv(child_by_ctx(bch,1), realm); sname=principal_from_tlv(child_by_ctx(bch,3), realm)
            if realm: parts.append(f'realm={realm}')
            if cname: parts.append(f'client={cname}')
            if sname: parts.append(f'spn={sname}')
        return ' '.join(parts)
    if app in (11,13):
        realm=string_from_tlv(child_by_ctx(top,3)); cname=principal_from_tlv(child_by_ctx(top,4), realm)
        if realm: parts.append(f'realm={realm}')
        if cname: parts.append(f'client={cname}')
        return ' '.join(parts)
    if app==30:
        code=int_from_tlv(child_by_ctx(top,6)); realm=string_from_tlv(child_by_ctx(top,9)); sname=principal_from_tlv(child_by_ctx(top,10), realm); etext=string_from_tlv(child_by_ctx(top,11))
        if code is not None: parts.append(f'error_code={code}({KRB_ERR.get(code,"UNKNOWN")})')
        if realm: parts.append(f'realm={realm}')
        if sname: parts.append(f'spn={sname}')
        if etext: parts.append(f'e_text={etext}')
        return ' '.join(parts)
    # AP-REQ/Tickets: best-effort search for realm and server principal.
    vals=strings_under(t)
    if vals: parts.append('strings=' + ','.join(vals[:8]))
    return ' '.join(parts)

# ----------------------------- protocol decoders -----------------------------
def parse_dns(payload):
    if len(payload)<12: return None
    tid,flags,qdcount,ancount,_,_=struct.unpack_from('!HHHHHH',payload,0); qr='response' if flags&0x8000 else 'query'; off=12; names=[]
    def read_name(pos,depth=0):
        labels=[]; after=None
        while pos<len(payload) and depth<12:
            ln=payload[pos]
            if ln==0: pos+=1; break
            if (ln&0xC0)==0xC0:
                if pos+1>=len(payload): return None,pos
                ptr=((ln&0x3F)<<8)|payload[pos+1]; after=pos+2; sub,_=read_name(ptr,depth+1)
                if sub: labels.append(sub)
                pos=after; break
            pos+=1
            if pos+ln>len(payload): return None,pos
            labels.append(payload[pos:pos+ln].decode('utf-8','replace')); pos+=ln
        return '.'.join(labels),pos
    for _ in range(min(qdcount,5)):
        name,off=read_name(off)
        if not name or off+4>len(payload): break
        qt,qc=struct.unpack_from('!HH',payload,off); off+=4; names.append(f'{name} type={qt} class={qc}')
    return f"DNS {qr} id=0x{tid:04x} q={'; '.join(names)} answers={ancount}" if names else f'DNS {qr} id=0x{tid:04x} questions={qdcount} answers={ancount}'

def app_hint(proto,sport,dport,payload):
    if not payload: return None
    if sport==88 or dport==88:
        k=parse_kerberos(payload)
        if k: return k
        return 'Kerberos payload (unable to decode ASN.1 summary)'
    if proto=='UDP' and (sport in (53,5353) or dport in (53,5353)): return parse_dns(payload)
    if proto=='TCP' and (sport==53 or dport==53) and len(payload)>2: return parse_dns(payload[2:2+int.from_bytes(payload[:2],'big')])
    starts=[b'GET ',b'POST ',b'PUT ',b'DELETE ',b'HEAD ',b'OPTIONS ',b'PATCH ',b'CONNECT ',b'TRACE ',b'HTTP/1.',b'HTTP/2']
    if any(payload.startswith(x) for x in starts) or sport in (80,8080,8000) or dport in (80,8080,8000): return 'HTTP ' + payload.split(b'\r\n',1)[0].decode('utf-8','replace')
    if sport in (443,8443) or dport in (443,8443):
        sni=parse_tls_sni(payload)
        if sni: return f'TLS ClientHello SNI={sni}'
        if payload[0] in (20,21,22,23): return 'TLS/SSL record'
    asc=ascii_preview(payload,220)
    if '[Signage]' in asc or 'Signage' in asc or '>>>>' in asc: return 'SIGNAGE ' + asc
    return None

def tcp_flags_text(flags):
    names=[]
    for bit,name in ((1,'FIN'),(2,'SYN'),(4,'RST'),(8,'PSH'),(16,'ACK'),(32,'URG'),(64,'ECE'),(128,'CWR')):
        if flags&bit: names.append(name)
    return ','.join(names) if names else 'none'

def base_rec(): return {'link':None,'net':None,'l4':None,'app':None,'payload':b'','src':None,'dst':None,'sport':None,'dport':None,'l4_proto':None,'ip_version':None,'tcp_flags':None,'payload_len':0}

def dissect_transport(rec, proto_num, payload):
    if proto_num==6:
        if len(payload)<20: rec['l4']='TCP truncated'; return rec
        sport=int.from_bytes(payload[0:2],'big'); dport=int.from_bytes(payload[2:4],'big'); seq=int.from_bytes(payload[4:8],'big'); ack=int.from_bytes(payload[8:12],'big'); doff=(payload[12]>>4)*4; flags=payload[13]; win=int.from_bytes(payload[14:16],'big'); tcp_payload=payload[doff:] if doff<=len(payload) else b''
        rec.update({'l4_proto':'TCP','sport':sport,'dport':dport,'tcp_flags':tcp_flags_text(flags),'payload':tcp_payload,'payload_len':len(tcp_payload)}); rec['l4']=f"TCP {sport} -> {dport} flags={rec['tcp_flags']} seq={seq} ack={ack} win={win} payload_len={len(tcp_payload)}"; rec['app']=app_hint('TCP',sport,dport,tcp_payload); return rec
    if proto_num==17:
        if len(payload)<8: rec['l4']='UDP truncated'; return rec
        sport=int.from_bytes(payload[0:2],'big'); dport=int.from_bytes(payload[2:4],'big'); ln=int.from_bytes(payload[4:6],'big'); udp_payload=payload[8:]
        rec.update({'l4_proto':'UDP','sport':sport,'dport':dport,'payload':udp_payload,'payload_len':len(udp_payload)}); rec['l4']=f'UDP {sport} -> {dport} len={ln} payload_len={len(udp_payload)}'; rec['app']=app_hint('UDP',sport,dport,udp_payload); return rec
    if proto_num==1 and len(payload)>=4: rec.update({'l4_proto':'ICMP','l4':f'ICMP type={payload[0]} code={payload[1]}','payload':payload[4:],'payload_len':len(payload[4:])}); return rec
    if proto_num==58 and len(payload)>=4: rec.update({'l4_proto':'ICMPv6','l4':f'ICMPv6 type={payload[0]} code={payload[1]}','payload':payload[4:],'payload_len':len(payload[4:])}); return rec
    pname=PROTO.get(proto_num,str(proto_num)); rec.update({'l4_proto':pname,'l4':pname,'payload':payload,'payload_len':len(payload)}); return rec

def dissect_ipv4(pkt):
    rec=base_rec()
    if len(pkt)<20: rec['net']='IPv4 truncated'; return rec
    ihl=(pkt[0]&0x0F)*4
    if pkt[0]>>4!=4 or ihl<20 or len(pkt)<ihl: rec['net']='IPv4 malformed'; return rec
    total=int.from_bytes(pkt[2:4],'big'); ident=int.from_bytes(pkt[4:6],'big'); frag=int.from_bytes(pkt[6:8],'big'); ttl=pkt[8]; proto=pkt[9]; src=ip4(pkt[12:16]); dst=ip4(pkt[16:20]); eff=min(total,len(pkt)) if total else len(pkt); payload=pkt[ihl:eff]
    flags=frag>>13; frag_off=frag&0x1FFF; frag_text=f' flags=0x{flags:x} frag_offset={frag_off}' if flags or frag_off else ''
    rec.update({'ip_version':'IPv4','src':src,'dst':dst}); rec['net']=f'IPv4 {src} -> {dst} proto={PROTO.get(proto,proto)} ttl={ttl} id=0x{ident:04x} len={total}{frag_text}'
    if frag_off: rec.update({'l4':'fragment continuation','payload':payload,'payload_len':len(payload)}); return rec
    return dissect_transport(rec,proto,payload)

def dissect_ipv6(pkt):
    rec=base_rec()
    if len(pkt)<40: rec['net']='IPv6 truncated'; return rec
    if pkt[0]>>4!=6: rec['net']='IPv6 malformed'; return rec
    payload_len=int.from_bytes(pkt[4:6],'big'); nh=pkt[6]; hop=pkt[7]; src=ip6(pkt[8:24]); dst=ip6(pkt[24:40]); off=40; ext=[]
    while nh in (0,43,44,50,51,60) and off+2<=len(pkt):
        ext.append(PROTO.get(nh,str(nh)))
        if nh==44:
            if off+8>len(pkt): break
            nh=pkt[off]; off+=8; break
        if nh==50: break
        hdr_len=(pkt[off+1]+1)*8; nh=pkt[off]; off+=hdr_len
    rec.update({'ip_version':'IPv6','src':src,'dst':dst}); rec['net']=f'IPv6 {src} -> {dst} next={PROTO.get(nh,nh)} hop={hop} payload_len={payload_len}' + (f" ext={','.join(ext)}" if ext else '')
    return dissect_transport(rec,nh,pkt[off:])

def dissect_l3(pkt, ethertype):
    if ethertype==0x0800: return dissect_ipv4(pkt)
    if ethertype==0x86DD: return dissect_ipv6(pkt)
    rec=base_rec(); rec['net']='ARP' if ethertype==0x0806 else f'Ethertype 0x{ethertype:04x}'
    if ethertype!=0x0806: rec.update({'payload':pkt,'payload_len':len(pkt)})
    return rec

def dissect_packet(pkt, linktype):
    if linktype==LINKTYPE_ETHERNET:
        if len(pkt)<14: rec=base_rec(); rec['link']='Ethernet truncated'; return rec
        dst=mac(pkt[0:6]); src=mac(pkt[6:12]); ethertype=int.from_bytes(pkt[12:14],'big'); off=14; vlans=[]
        while ethertype in (0x8100,0x88A8,0x9100) and off+4<=len(pkt): vlans.append(int.from_bytes(pkt[off:off+2],'big')&0x0FFF); ethertype=int.from_bytes(pkt[off+2:off+4],'big'); off+=4
        rec=dissect_l3(pkt[off:],ethertype); rec['link']=f"Ethernet {src} -> {dst} ethertype=0x{ethertype:04x}" + (f" vlan={','.join(map(str,vlans))}" if vlans else ''); return rec
    if linktype==LINKTYPE_LINUX_SLL and len(pkt)>=16:
        proto=int.from_bytes(pkt[14:16],'big'); rec=dissect_l3(pkt[16:],proto); rec['link']=f'Linux cooked SLL proto=0x{proto:04x}'; return rec
    if linktype==LINKTYPE_LINUX_SLL2 and len(pkt)>=20:
        proto=int.from_bytes(pkt[0:2],'big'); ifidx=int.from_bytes(pkt[4:8],'big'); rec=dissect_l3(pkt[20:],proto); rec['link']=f'Linux cooked SLL2 if_index={ifidx} proto=0x{proto:04x}'; return rec
    rec=base_rec(); rec.update({'link':f'Unsupported/truncated linktype={linktype}','payload':pkt,'payload_len':len(pkt)}); return rec

# ----------------------------- reporting/extraction -----------------------------
def iter_records(input_path,max_packets=None):
    for pktinfo in PcapngReader(input_path).read_packets():
        if max_packets and pktinfo['frame']>max_packets: break
        d=dissect_packet(pktinfo['data'], pktinfo['iface'].get('linktype')); rec=dict(d); rec.update(pktinfo); rec['time']=fmt_ts(pktinfo['ts']); yield rec

def parse_frame_ranges(spec):
    if not spec: return None
    frames=set()
    for part in spec.split(','):
        part=part.strip()
        if not part: continue
        if '-' in part:
            a,b=part.split('-',1); frames.update(range(int(a),int(b)+1))
        else: frames.add(int(part))
    return frames

def parse_endpoint(text):
    text=text.strip()
    if text.startswith('['):
        host,rest=text[1:].split(']',1); return host, int(rest[1:]) if rest.startswith(':') else None
    if ':' in text and text.count(':')==1:
        h,p=text.rsplit(':',1); return h,int(p)
    return text,None

def parse_flow(spec):
    if not spec: return None
    sep=',' if ',' in spec else '<->' if '<->' in spec else '->' if '->' in spec else None
    if not sep: raise ValueError('Flow must look like src_ip:port,dst_ip:port or src_ip:port->dst_ip:port')
    left,right=spec.split(sep,1); return parse_endpoint(left),parse_endpoint(right)

def ep_match(ep,target):
    h,p=target; return ep[0]==h and (p is None or ep[1]==p)
def flow_match(rec,flow):
    if not flow: return True
    a=(rec.get('src'),rec.get('sport')); b=(rec.get('dst'),rec.get('dport')); (h1,p1),(h2,p2)=flow
    return (ep_match(a,(h1,p1)) and ep_match(b,(h2,p2))) or (ep_match(a,(h2,p2)) and ep_match(b,(h1,p1)))
def record_match(rec,frame_set=None,flow=None,host=None): return (frame_set is None or rec['frame'] in frame_set) and flow_match(rec,flow) and (not host or rec.get('src')==host or rec.get('dst')==host)

def write_detailed_records(records,out,source,title='pcapng_quickdump',hex_preview_len=96):
    out.write(f'# {title}\n# source: {source}\n# note: standalone quick triage; no Wireshark/tshark used\n\n'); count=0
    for rec in records:
        count+=1; name=rec['iface'].get('name') or ''
        out.write('='*88+'\n'); out.write(f"Frame {rec['frame']} time={rec['time']} caplen={rec['caplen']} origlen={rec['origlen']} iface={rec['iface_id']} {name} file_offset={rec['file_off']}\n")
        out.write(f"Link: {rec.get('link')}\n")
        if rec.get('net'): out.write(f"Network: {rec.get('net')}\n")
        if rec.get('l4'): out.write(f"Transport: {rec.get('l4')}\n")
        if rec.get('app'): out.write(f"Application: {rec.get('app')}\n")
        payload=rec.get('payload') or b''
        if payload:
            hp,ap=hex_preview(payload,hex_preview_len); out.write(f'PayloadASCII: {ascii_preview(payload)}\nPayloadHEX: {hp}\nPayloadPreview: {ap}\n')
        out.write('\n')
    out.write(f'# packets_written: {count}\n')

def write_detailed(input_path,out,max_packets=None,hex_preview_len=96): write_detailed_records(iter_records(input_path,max_packets),out,input_path,'pcapng_quickdump',hex_preview_len)
def write_targeted(input_path,out,frames=None,flow=None,host=None,max_packets=None,hex_preview_len=96):
    fs=parse_frame_ranges(frames); fo=parse_flow(flow) if flow else None; title='pcapng_quickdump targeted extraction ' + ' '.join(x for x in [f'frames={frames}' if frames else '', f'flow={flow}' if flow else '', f'host={host}' if host else ''] if x)
    write_detailed_records((r for r in iter_records(input_path,max_packets) if record_match(r,fs,fo,host)),out,input_path,title,hex_preview_len)

def duration(a,b): return 'n/a' if a is None or b is None else f'{max(0,b-a):.6f}s'
def write_summary(input_path,out,max_packets=None,top_n=100):
    flows={}; tp=tb=0; first=last=None
    for r in iter_records(input_path,max_packets):
        tp+=1; tb+=r['origlen'];
        if r['ts'] is not None: first=r['ts'] if first is None else min(first,r['ts']); last=r['ts'] if last is None else max(last,r['ts'])
        key=(r.get('l4_proto') or r.get('net') or 'OTHER',r.get('src') or 'n/a',r.get('sport') or 0,r.get('dst') or 'n/a',r.get('dport') or 0)
        f=flows.setdefault(key,{'packets':0,'bytes':0,'payload_bytes':0,'first':r['ts'],'last':r['ts'],'first_frame':r['frame'],'last_frame':r['frame'],'apps':Counter(),'tcp_flags':Counter()})
        f['packets']+=1; f['bytes']+=r['origlen']; f['payload_bytes']+=r.get('payload_len') or 0; f['last_frame']=r['frame']
        if r['ts'] is not None: f['first']=r['ts'] if f['first'] is None else min(f['first'],r['ts']); f['last']=r['ts'] if f['last'] is None else max(f['last'],r['ts'])
        if r.get('app'): f['apps'][r['app'].split()[0].upper()] += 1
        if r.get('tcp_flags'): f['tcp_flags'][r['tcp_flags']] += 1
    out.write(f'# pcapng_quickdump flow summary\n# source: {input_path}\n# packets: {tp}\n# bytes: {tb}\n# duration: {duration(first,last)}\n# flows: {len(flows)}\n\nTop flows by bytes\n'+'='*88+'\n')
    for i,(k,f) in enumerate(sorted(flows.items(),key=lambda kv:kv[1]['bytes'],reverse=True)[:top_n],1):
        proto,src,sport,dst,dport=k; apps=','.join(f'{x}:{y}' for x,y in f['apps'].most_common(5)) or '-'; flags=','.join(f'{x}:{y}' for x,y in f['tcp_flags'].most_common(5)) or '-'
        out.write(f"{i:04d} {proto} {src}:{sport} -> {dst}:{dport} packets={f['packets']} bytes={f['bytes']} payload_bytes={f['payload_bytes']} frames={f['first_frame']}-{f['last_frame']} duration={duration(f['first'],f['last'])} apps={apps} tcp_flags={flags}\n")

def write_hosts(input_path,out,max_packets=None,top_n=100):
    hosts=defaultdict(lambda:{'tx_packets':0,'rx_packets':0,'tx_bytes':0,'rx_bytes':0}); endpoints=Counter(); ports=Counter(); conv=Counter(); prot=Counter(); total=0
    for r in iter_records(input_path,max_packets):
        total+=1; proto=r.get('l4_proto') or r.get('net') or 'OTHER'; prot[proto]+=1; s=r.get('src'); d=r.get('dst'); sp=r.get('sport'); dp=r.get('dport')
        if s: hosts[s]['tx_packets']+=1; hosts[s]['tx_bytes']+=r['origlen']
        if d: hosts[d]['rx_packets']+=1; hosts[d]['rx_bytes']+=r['origlen']
        if s and sp: endpoints[(s,proto,sp)]+=1; ports[(proto,sp)]+=1
        if d and dp: endpoints[(d,proto,dp)]+=1; ports[(proto,dp)]+=1
        if s and d: conv[(proto,tuple(sorted([(s,sp or 0),(d,dp or 0)])))] += r['origlen']
    out.write(f'# pcapng_quickdump endpoint and port stats\n# source: {input_path}\n# packets: {total}\n\nProtocol packet counts\n'+'='*88+'\n')
    for p,c in prot.most_common(): out.write(f'{p} packets={c}\n')
    out.write('\nTop hosts by total bytes\n'+'='*88+'\n')
    for i,(h,v) in enumerate(sorted(hosts.items(),key=lambda kv:kv[1]['tx_bytes']+kv[1]['rx_bytes'],reverse=True)[:top_n],1): out.write(f"{i:04d} host={h} total_bytes={v['tx_bytes']+v['rx_bytes']} tx_packets={v['tx_packets']} tx_bytes={v['tx_bytes']} rx_packets={v['rx_packets']} rx_bytes={v['rx_bytes']}\n")
    out.write('\nTop host:port endpoints by packet count\n'+'='*88+'\n')
    for i,((h,p,port),c) in enumerate(endpoints.most_common(top_n),1): out.write(f'{i:04d} {h}:{port}/{p} packets={c}\n')
    out.write('\nTop ports by packet count\n'+'='*88+'\n')
    for i,((p,port),c) in enumerate(ports.most_common(top_n),1): out.write(f'{i:04d} port={port}/{p} packets={c}\n')
    out.write('\nTop conversations by bytes\n'+'='*88+'\n')
    for i,((p,pair),b) in enumerate(conv.most_common(top_n),1):
        (h1,p1),(h2,p2)=pair; out.write(f'{i:04d} {p} {h1}:{p1} <-> {h2}:{p2} bytes={b}\n')

def write_apps(input_path,out,max_packets=None,top_n=200):
    counts=Counter(); buckets=defaultdict(Counter); events=[]
    for r in iter_records(input_path,max_packets):
        app=r.get('app')
        if not app: continue
        cat='KERBEROS' if app.startswith('Kerberos') else app.split()[0].upper()
        if cat.startswith('DNS'): cat='DNS'
        elif cat.startswith('HTTP'): cat='HTTP'
        elif cat.startswith('TLS'): cat='TLS'
        elif cat.startswith('SIGNAGE'): cat='SIGNAGE'
        counts[cat]+=1; buckets[cat][app]+=1; events.append((r,cat,app))
    out.write(f'# pcapng_quickdump application hints\n# source: {input_path}\n# app_events: {len(events)}\n\nApplication category counts\n'+'='*88+'\n')
    for k,c in counts.most_common(): out.write(f'{k} count={c}\n')
    for title,cat in [('Kerberos hints','KERBEROS'),('DNS hints','DNS'),('HTTP hints','HTTP'),('TLS hints','TLS'),('Signage/control hints','SIGNAGE')]:
        out.write(f'\n{title}\n'+'='*88+'\n')
        if not buckets[cat]: out.write('none\n')
        for i,(item,c) in enumerate(buckets[cat].most_common(top_n),1): out.write(f'{i:04d} count={c} {item}\n')
    out.write('\nChronological application events\n'+'='*88+'\n')
    for r,cat,app in events[:top_n]: out.write(f"Frame {r['frame']} time={r['time']} {r.get('l4_proto') or 'OTHER'} {r.get('src') or 'n/a'}:{r.get('sport') or 0} -> {r.get('dst') or 'n/a'}:{r.get('dport') or 0} category={cat} detail={app}\n")

def derive(input_path,output=None,report_dir=None):
    inp=os.path.abspath(input_path)
    if output: detailed=os.path.abspath(output); base=os.path.dirname(detailed); stem=os.path.splitext(os.path.basename(detailed))[0]
    else: base=os.path.abspath(report_dir or os.path.dirname(inp) or os.getcwd()); stem=os.path.splitext(os.path.basename(input_path))[0]+'_quickdump'; detailed=os.path.join(base,stem+'.txt')
    if report_dir: base=os.path.abspath(report_dir); os.makedirs(base,exist_ok=True); detailed=os.path.join(base,os.path.basename(detailed))
    return {'detailed':detailed,'summary':os.path.join(base,stem+'_summary.txt'),'hosts':os.path.join(base,stem+'_hosts.txt'),'apps':os.path.join(base,stem+'_apps.txt'),'triage':os.path.join(base,stem+'_triage.txt'),'extract':os.path.join(base,stem+'_extract.txt')}

def write_triage(paths,source):
    with open(paths['triage'],'w',encoding='utf-8',newline='\n') as out:
        out.write(f'# pcapng_quickdump triage bundle\n# source: {source}\n# contains: flow summary + endpoint/port stats + DNS/HTTP/TLS/Kerberos/signage hints\n\n')
        for title,k in [('FLOW SUMMARY','summary'),('ENDPOINT / PORT STATS','hosts'),('APPLICATION HINTS','apps')]:
            out.write('='*96+'\n'+f'SECTION: {title}\n'+'='*96+'\n')
            with open(paths[k],'r',encoding='utf-8',errors='replace') as f: out.write(f.read())
            out.write('\n\n')

def generated(files):
    print('Generated:')
    for p in files: print(f"  {p}  {'OK' if os.path.exists(p) else 'MISSING'} bytes={os.path.getsize(p) if os.path.exists(p) else 0}")

def main():
    ap=argparse.ArgumentParser(description='Standalone PCAPNG quick text dissector/report generator')
    ap.add_argument('input'); ap.add_argument('-o','--output'); ap.add_argument('--max-packets',type=int); ap.add_argument('--hex-preview-len',type=int,default=96)
    ap.add_argument('--summary',action='store_true'); ap.add_argument('--top-talkers',action='store_true'); ap.add_argument('--apps',action='store_true'); ap.add_argument('--triage',action='store_true'); ap.add_argument('--all-reports',action='store_true')
    ap.add_argument('--frames'); ap.add_argument('--flow'); ap.add_argument('--host'); ap.add_argument('--extract-output')
    ap.add_argument('--report-dir'); ap.add_argument('--summary-output'); ap.add_argument('--hosts-output'); ap.add_argument('--apps-output'); ap.add_argument('--triage-output'); ap.add_argument('--top-n',type=int,default=100)
    a=ap.parse_args(); paths=derive(a.input,a.output,a.report_dir)
    for key,val in [('summary',a.summary_output),('hosts',a.hosts_output),('apps',a.apps_output),('triage',a.triage_output),('extract',a.extract_output)]:
        if val: paths[key]=val
    extract=bool(a.frames or a.flow or a.host); mode=a.all_reports or a.summary or a.top_talkers or a.apps or a.triage or extract
    if not mode:
        if a.output:
            with open(a.output,'w',encoding='utf-8',newline='\n') as f: write_detailed(a.input,f,a.max_packets,a.hex_preview_len)
        else: write_detailed(a.input,sys.stdout,a.max_packets,a.hex_preview_len)
        return
    out=[]
    if a.all_reports:
        with open(paths['detailed'],'w',encoding='utf-8',newline='\n') as f: write_detailed(a.input,f,a.max_packets,a.hex_preview_len)
        out.append(paths['detailed'])
    if a.all_reports or a.summary or a.triage:
        with open(paths['summary'],'w',encoding='utf-8',newline='\n') as f: write_summary(a.input,f,a.max_packets,a.top_n)
        out.append(paths['summary'])
    if a.all_reports or a.top_talkers or a.triage:
        with open(paths['hosts'],'w',encoding='utf-8',newline='\n') as f: write_hosts(a.input,f,a.max_packets,a.top_n)
        out.append(paths['hosts'])
    if a.all_reports or a.apps or a.triage:
        with open(paths['apps'],'w',encoding='utf-8',newline='\n') as f: write_apps(a.input,f,a.max_packets,a.top_n)
        out.append(paths['apps'])
    if a.all_reports or a.triage:
        write_triage(paths,a.input); out.append(paths['triage'])
    if extract:
        with open(paths['extract'],'w',encoding='utf-8',newline='\n') as f: write_targeted(a.input,f,a.frames,a.flow,a.host,a.max_packets,a.hex_preview_len)
        out.append(paths['extract'])
    generated(out)
if __name__=='__main__': main()
