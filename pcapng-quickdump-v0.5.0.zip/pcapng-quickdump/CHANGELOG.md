# Changelog

## 0.5.0 - 2026-06-16

- Added lightweight Kerberos decoding for UDP/TCP port 88.
- Added Kerberos message type summaries: AS-REQ, AS-REP, TGS-REQ, TGS-REP, AP-REQ, AP-REP, KRB-ERROR.
- Added requested SPN extraction from KDC-REQ-BODY.sname when present.
- Added realm and client principal extraction when present.
- Added KDC error-code extraction and symbolic error names for KRB-ERROR.
- Added Kerberos category to application reports and triage bundles.
- Added TCP Kerberos 4-byte record-length prefix handling.

## 0.4.0 - 2026-05-29

- Added targeted frame, flow, and host extraction.

## 0.3.0 - 2026-05-29

- Added triage bundle report.

## 0.2.0 - 2026-05-29

- Added summary, top-talkers, and apps reports.

## 0.1.0 - 2026-05-29

- Initial Python-only PCAPNG quickdump utility.
