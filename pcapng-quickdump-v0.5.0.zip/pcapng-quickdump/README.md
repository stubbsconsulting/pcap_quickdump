# pcapng-quickdump

Standalone PCAPNG quick text dissector/report generator in pure Python.

## v0.5.0 Kerberos support

Kerberos traffic on UDP/TCP port 88 is now summarized in detailed output, app reports, triage reports, and targeted extractions.

Best-effort Kerberos decoding includes:

- Kerberos message type, such as `AS-REQ`, `TGS-REQ`, `AS-REP`, `TGS-REP`, and `KRB-ERROR`
- Requested service principal name / SPN when present in `KDC-REQ-BODY.sname`
- Realm
- Client principal when present
- KDC error code and symbolic name for `KRB-ERROR`
- TCP Kerberos 4-byte record-length prefix handling

## Generate all reports

```powershell
python .\pcapng_quickdump.py .	race.pcapng --all-reports
```

## Triage-only mode

```powershell
python .\pcapng_quickdump.py .	race.pcapng --triage
```

## Kerberos-focused examples

Extract all packets for a domain controller / KDC:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --host 10.211.4.251 --extract-output .	race_kdc_host.txt
```

Extract a Kerberos flow:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --flow 10.130.2.5:50295,10.211.4.251:88 --extract-output .	race_kerberos_flow.txt
```

Run app hints only:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --apps
```

## Limitations

This is a lightweight ASN.1/Kerberos triage parser, not a complete Wireshark dissector. It does not decrypt tickets, decrypt authenticators, reassemble TCP streams, or decode every Kerberos extension.
