# Manual hotfix for pcapng_quickdump.py v0.5.0

Your current script references `parse_tls_sni(payload)` inside `app_hint()`, but the function was accidentally omitted from v0.5.0.

## Fast patch

From the same folder as `pcapng_quickdump.py`, run:

```powershell
python .\patch_pcapng_quickdump_tls_sni.py .\pcapng_quickdump.py
```

Then rerun:

```powershell
python .\pcapng_quickdump.py .\rodrigo_vieira_TRACE_LS.pcapng --all-reports
```

The patcher creates a backup:

```text
pcapng_quickdump.py.bak
```

## Why this happened

v0.5.0 added Kerberos decoding, but during packaging the TLS SNI helper was dropped while `app_hint()` still called it for TCP/443 traffic. The patch inserts the missing helper function and syntax-checks the resulting script.
