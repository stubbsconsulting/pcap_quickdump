# Changelog

## 0.5.1 - 2026-06-16

- Hotfix: restored missing `parse_tls_sni()` helper referenced by `app_hint()`.
- Adds a patcher script to repair existing `pcapng_quickdump.py` v0.5.0 files in place.
