#!/usr/bin/env python3
"""
patch_pcapng_quickdump_tls_sni.py

Hotfix for pcapng_quickdump.py v0.5.0 where parse_tls_sni() was referenced
but not included in the generated source.

Usage:
  python .\patch_pcapng_quickdump_tls_sni.py .\pcapng_quickdump.py
"""
from pathlib import Path
import sys
import py_compile

TLS_SNI_FUNCTION = r