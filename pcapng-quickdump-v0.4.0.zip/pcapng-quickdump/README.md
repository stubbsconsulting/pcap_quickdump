# pcapng-quickdump

Standalone PCAPNG-to-text quick packet dissector and report generator written in pure Python.

No Wireshark, TShark, libpcap, or third-party Python packages are required.

## Generate all reports

```powershell
python .\pcapng_quickdump.py .	race.pcapng --all-reports
```

Creates:

```text
trace_quickdump.txt              # detailed frames
trace_quickdump_summary.txt      # flow summary
trace_quickdump_hosts.txt        # endpoint/port stats
trace_quickdump_apps.txt         # DNS/HTTP/TLS/signage hints
trace_quickdump_triage.txt       # summary + hosts + apps combined
```

## Triage-only mode

```powershell
python .\pcapng_quickdump.py .	race.pcapng --triage
```

## Targeted extraction

Extract specific frame ranges:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --frames 2500-2620 --extract-output .	race_frames_2500_2620.txt
```

Extract a bidirectional flow:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --flow 10.130.2.5:50048,52.122.3.166:3481 --extract-output .	race_flow_teams_udp.txt
```

Extract all packets for a host:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --host 52.122.3.166 --extract-output .	race_host_52_122_3_166.txt
```

Combine selectors; they are ANDed together:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --host 198.217.0.23 --frames 2500-2620 --extract-output .	race_host_frame_slice.txt
```

If `--extract-output` is omitted, the default is:

```text
trace_quickdump_extract.txt
```

## Recommended upload workflow

Upload `trace_quickdump_triage.txt` first. If detail is needed, upload a targeted extraction file created with `--frames`, `--flow`, or `--host`.

## License

MIT License. See [LICENSE](LICENSE).
