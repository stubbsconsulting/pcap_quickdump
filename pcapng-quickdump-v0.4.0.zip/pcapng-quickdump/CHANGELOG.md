# Changelog

## 0.4.0 - 2026-05-29

- Added targeted frame extraction with `--frames`.
- Added targeted bidirectional flow extraction with `--flow`.
- Added targeted host extraction with `--host`.
- Added `--extract-output` for naming extraction files.
- Extraction selectors can be combined and are ANDed together.

## 0.3.0 - 2026-05-29

- Added `--triage` option.
- Added `trace_quickdump_triage.txt`, combining summary + hosts + apps.
- Updated `--all-reports` to generate five files.

## 0.2.0 - 2026-05-29

- Added `--summary`, `--top-talkers`, and `--apps`.

## 0.1.0 - 2026-05-29

- Initial Python-only PCAPNG quickdump utility.
