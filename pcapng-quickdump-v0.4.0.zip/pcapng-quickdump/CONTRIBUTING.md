# Contributing

Near-term focus areas:

1. CSV and JSON report formats
2. Optional classic `.pcap` support
3. More app-layer hints
4. Unit tests with sanitized fixtures
