# pcapng-quickdump

Standalone PCAPNG-to-text quick packet dissector and report generator written in pure Python.

No Wireshark, TShark, libpcap, or third-party Python packages are required.

## Quick start: generate all five reports

```powershell
python .\pcapng_quickdump.py .	race.pcapng --all-reports
```

For `trace.pcapng`, `--all-reports` creates:

```text
trace_quickdump.txt              # detailed frames
trace_quickdump_summary.txt      # flow summary
trace_quickdump_hosts.txt        # endpoint/port stats
trace_quickdump_apps.txt         # DNS/HTTP/TLS/signage hints
trace_quickdump_triage.txt       # summary + hosts + apps combined
```

## Triage-only mode

Use this when you want one compact file for upload and analysis:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --triage
```

`--triage` generates the three underlying analytical reports and then combines them into:

```text
trace_quickdump_triage.txt
```

## Individual reports

```powershell
python .\pcapng_quickdump.py .	race.pcapng --summary
python .\pcapng_quickdump.py .	race.pcapng --top-talkers
python .\pcapng_quickdump.py .	race.pcapng --apps
```

Detailed frames only:

```powershell
python .\pcapng_quickdump.py .	race.pcapng -o .	race_quickdump.txt
```

Explicit output names:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --all-reports `
  -o .	race_quickdump.txt `
  --summary-output .	race_quickdump_summary.txt `
  --hosts-output .	race_quickdump_hosts.txt `
  --apps-output .	race_quickdump_apps.txt `
  --triage-output .	race_quickdump_triage.txt
```

## Recommended upload workflow

Upload `trace_quickdump_triage.txt` first. Upload `trace_quickdump.txt` only if packet-by-packet detail is needed.

## Limitations

- PCAPNG only; classic `.pcap` is not implemented yet.
- No TCP stream reassembly.
- No IP fragment reassembly.
- No TLS decryption.
- Limited application-layer decoding.

## License

MIT License. See [LICENSE](LICENSE).
