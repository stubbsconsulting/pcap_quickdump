# Changelog

## 0.3.0 - 2026-05-29

- Added `--triage` option.
- Added `trace_quickdump_triage.txt`, combining summary + hosts + apps.
- Updated `--all-reports` to generate five files: detailed, summary, hosts, apps, and triage.
- Added generated-file verification output with file sizes.

## 0.2.0 - 2026-05-29

- Added `--summary` flow summary report.
- Added `--top-talkers` endpoint and port statistics report.
- Added `--apps` DNS/HTTP/TLS/signage application hints report.
- Added `--all-reports` to create the original four-file upload bundle.

## 0.1.0 - 2026-05-29

- Initial Python-only PCAPNG quickdump utility.
