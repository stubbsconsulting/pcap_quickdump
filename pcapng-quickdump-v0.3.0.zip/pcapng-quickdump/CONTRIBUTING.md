# Contributing

Near-term focus areas:

1. Filters by host, port, protocol, flow, and app hint
2. CSV and JSON report formats
3. Optional classic `.pcap` support
4. More app-layer hints

Please avoid committing packet captures or generated trace dumps unless sanitized and intentionally included as test fixtures.
