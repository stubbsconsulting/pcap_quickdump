# pcapng-quickdump

Standalone PCAPNG-to-text quick packet dissector written in pure Python.

This project is designed for fast packet-trace triage when you want an upload-friendly `.txt` output from a `.pcapng` file without using Wireshark, TShark, libpcap, or third-party Python packages.

## Current status

This is the initial Python-only version. It focuses on detailed frame output and lightweight protocol hints.

Planned next work:

- Detailed frame output refinements
- Endpoint and port statistics
- DNS / HTTP / TLS / signage hints
- Flow summaries
- Filtering by host, port, protocol, or application hint

## Features

- Pure Python standard library only
- Reads PCAPNG files directly
- Supports:
  - Section Header Blocks
  - Interface Description Blocks
  - Enhanced Packet Blocks
  - Simple Packet Blocks
- Handles common link types:
  - Ethernet / LINKTYPE 1
  - Linux cooked capture / LINKTYPE 113
  - Linux cooked capture v2 / LINKTYPE 276
- Decodes:
  - Ethernet
  - IPv4
  - IPv6
  - TCP
  - UDP
  - ICMP
  - ICMPv6
  - ARP label
- Application hints:
  - DNS query names
  - HTTP request/status preview
  - TLS ClientHello SNI when visible
  - TLS/SSL record indicator
- Produces upload-friendly text with:
  - Frame number
  - Timestamp
  - Interface
  - MAC addresses
  - IP addresses
  - Ports
  - TCP flags
  - Payload length
  - ASCII preview
  - HEX preview

## Requirements

- Python 3.9 or newer recommended
- No external Python packages required

## Quick start

```powershell
python .\pcapng_quickdump.py .	race.pcapng -o .	race_quickdump.txt
```

Limit packet count:

```powershell
python .\pcapng_quickdump.py .	race.pcapng -o .irst5000.txt --max-packets 5000
```

Increase payload preview length:

```powershell
python .\pcapng_quickdump.py .	race.pcapng -o .	race_quickdump.txt --hex-preview-len 128
```

Write to stdout:

```bash
python3 ./pcapng_quickdump.py ./trace.pcapng
```

## Example output

```text
# pcapng_quickdump
# source: ./trace.pcapng
# size_bytes: 2335176
# note: standalone quick triage; no Wireshark/tshark used

========================================================================================
Frame 1 time=2026-04-22T15:16:41.855490+00:00 caplen=195 origlen=195 iface=0 file_offset=328
Link: Ethernet 00:ea:bd:88:35:27 -> e8:cf:83:ac:8c:7d ethertype=0x0800
Network: IPv4 52.122.3.166 -> 10.130.2.5 proto=UDP ttl=110 id=0x1bfd len=181
Transport: UDP 3479 -> 50007 len=161 payload_len=153
PayloadASCII: .m.......................w.6..d....
PayloadHEX: 92 6d ce d5 16 5b d3 fa ...
PayloadPreview: .m...[....................
```

## Limitations

This tool is for quick triage, not full Wireshark parity.

Known limitations:

- No TCP stream reassembly
- No IP fragment reassembly
- No decompression
- No TLS decryption
- Limited protocol decoding
- No capture filtering yet
- PCAPNG only; classic `.pcap` support is not currently implemented

## Security and privacy note

Packet captures can contain sensitive information including internal IP addresses, hostnames, URLs, tokens, cookies, payloads, and user data. Review generated text before sharing externally.

## Suggested GitHub workflow

```bash
git init
git add .
git commit -m "Initial Python pcapng quickdump utility"
```

## License

MIT License. See [LICENSE](LICENSE).
