#!/usr/bin/env python3
"""
pcapng_quickdump.py

Standalone PCAPNG-to-text quick dissector.
No Wireshark, no tshark, no third-party Python packages.

Supports:
  - PCAPNG Section Header, Interface Description, Enhanced Packet, Simple Packet
  - Ethernet LINKTYPE 1
  - Linux cooked LINKTYPE 113
  - Linux cooked v2 LINKTYPE 276
  - IPv4, IPv6
  - TCP, UDP, ICMP, ICMPv6
  - DNS query extraction
  - HTTP preview
  - TLS ClientHello SNI extraction
  - Hex/ASCII preview

Limitations:
  - No TCP stream reassembly
  - No IP fragment reassembly
  - No decompression
  - Encrypted payloads are not decrypted
  - Designed for fast triage and upload-friendly text, not full Wireshark parity
"""

import argparse
import datetime as _dt
import ipaddress
import os
import struct
import sys


SHB = 0x0A0D0D0A
IDB = 0x00000001
SPB = 0x00000003
EPB = 0x00000006

LINKTYPE_ETHERNET = 1
LINKTYPE_LINUX_SLL = 113
LINKTYPE_LINUX_SLL2 = 276

PROTO = {
    1: "ICMP",
    2: "IGMP",
    6: "TCP",
    17: "UDP",
    41: "IPv6",
    47: "GRE",
    50: "ESP",
    51: "AH",
    58: "ICMPv6",
    89: "OSPF",
}


def hexdump_preview(data, max_len=96):
    b = data[:max_len]
    hex_part = " ".join(f"{x:02x}" for x in b)
    ascii_part = "".join(chr(x) if 32 <= x <= 126 else "." for x in b)
    suffix = "" if len(data) <= max_len else f" ... +{len(data) - max_len} bytes"
    return hex_part, ascii_part + suffix


def mac_addr(b):
    return ":".join(f"{x:02x}" for x in b)


def ip4_addr(b):
    return ".".join(str(x) for x in b)


def ip6_addr(b):
    return str(ipaddress.IPv6Address(b))


def safe_ascii(data, max_len=160):
    b = data[:max_len]
    s = "".join(chr(x) if 32 <= x <= 126 else "." for x in b)
    if len(data) > max_len:
        s += f"... +{len(data) - max_len} bytes"
    return s


def fmt_ts(ts_seconds):
    if ts_seconds is None:
        return "n/a"
    try:
        return _dt.datetime.fromtimestamp(ts_seconds, tz=_dt.timezone.utc).isoformat()
    except Exception:
        return f"{ts_seconds:.6f}"


def u16(data, off, endian):
    return struct.unpack_from(endian + "H", data, off)[0]


def u32(data, off, endian):
    return struct.unpack_from(endian + "I", data, off)[0]


def parse_options(body, off, endian):
    opts = {}
    while off + 4 <= len(body):
        code = u16(body, off, endian)
        length = u16(body, off + 2, endian)
        off += 4
        if code == 0:
            break
        value = body[off:off + length]
        opts.setdefault(code, []).append(value)
        off += (length + 3) & ~3
    return opts


def parse_if_tsresol(opts):
    # Default is microseconds.
    resol = 1e-6
    vals = opts.get(9)
    if vals:
        v = vals[0][0]
        if v & 0x80:
            resol = 2 ** -(v & 0x7F)
        else:
            resol = 10 ** -v
    return resol


class PcapngReader:
    def __init__(self, path):
        self.path = path
        self.data = open(path, "rb").read()
        self.off = 0
        self.endian = "<"
        self.interfaces = []

    def _choose_shb_len_and_endian(self):
        if self.off + 12 > len(self.data):
            return None

        body_start = self.off + 8

        len_le = struct.unpack_from("<I", self.data, self.off + 4)[0]
        len_be = struct.unpack_from(">I", self.data, self.off + 4)[0]

        candidates = []
        for endian, blen in [("<", len_le), (">", len_be)]:
            if blen >= 28 and self.off + blen <= len(self.data):
                magic = struct.unpack_from(endian + "I", self.data, body_start)[0]
                if magic == 0x1A2B3C4D:
                    candidates.append((endian, blen))

        if not candidates:
            return None

        return candidates[0]

    def blocks(self):
        while self.off + 12 <= len(self.data):
            # Section Header Block is endian-independent by block type value.
            raw_type_le = struct.unpack_from("<I", self.data, self.off)[0]

            if raw_type_le == SHB:
                chosen = self._choose_shb_len_and_endian()
                if not chosen:
                    raise ValueError(f"Invalid Section Header Block at offset {self.off}")
                self.endian, blen = chosen
                btype = SHB
            else:
                btype = u32(self.data, self.off, self.endian)
                blen = u32(self.data, self.off + 4, self.endian)

            if blen < 12 or self.off + blen > len(self.data):
                raise ValueError(f"Invalid block length {blen} at file offset {self.off}")

            body = self.data[self.off + 8:self.off + blen - 4]
            trailer_len = u32(self.data, self.off + blen - 4, self.endian)

            if trailer_len != blen:
                # Be forgiving but warn in yielded metadata.
                pass

            cur_off = self.off
            self.off += blen
            yield btype, body, cur_off, blen

    def read_packets(self):
        frame_no = 0

        for btype, body, file_off, blen in self.blocks():
            if btype == SHB:
                self.interfaces = []
                continue

            if btype == IDB:
                if len(body) < 8:
                    continue
                linktype = u16(body, 0, self.endian)
                snaplen = u32(body, 4, self.endian)
                opts = parse_options(body, 8, self.endian)
                tsresol = parse_if_tsresol(opts)
                name = ""
                if 2 in opts:
                    try:
                        name = opts[2][0].decode("utf-8", "replace").rstrip("\x00")
                    except Exception:
                        name = ""
                self.interfaces.append({
                    "linktype": linktype,
                    "snaplen": snaplen,
                    "tsresol": tsresol,
                    "name": name,
                })
                continue

            if btype == EPB:
                if len(body) < 20:
                    continue
                iface_id = u32(body, 0, self.endian)
                ts_hi = u32(body, 4, self.endian)
                ts_lo = u32(body, 8, self.endian)
                caplen = u32(body, 12, self.endian)
                origlen = u32(body, 16, self.endian)

                pkt_start = 20
                pkt = body[pkt_start:pkt_start + caplen]

                iface = self.interfaces[iface_id] if iface_id < len(self.interfaces) else {
                    "linktype": None,
                    "tsresol": 1e-6,
                    "name": "",
                    "snaplen": 0,
                }

                ticks = (ts_hi << 32) | ts_lo
                ts = ticks * iface.get("tsresol", 1e-6)

                frame_no += 1
                yield {
                    "frame": frame_no,
                    "ts": ts,
                    "iface_id": iface_id,
                    "iface": iface,
                    "caplen": caplen,
                    "origlen": origlen,
                    "data": pkt,
                    "file_off": file_off,
                }

            elif btype == SPB:
                if len(body) < 4:
                    continue
                origlen = u32(body, 0, self.endian)
                pkt = body[4:4 + origlen]
                iface = self.interfaces[0] if self.interfaces else {
                    "linktype": LINKTYPE_ETHERNET,
                    "tsresol": 1e-6,
                    "name": "",
                    "snaplen": 0,
                }
                frame_no += 1
                yield {
                    "frame": frame_no,
                    "ts": None,
                    "iface_id": 0,
                    "iface": iface,
                    "caplen": len(pkt),
                    "origlen": origlen,
                    "data": pkt,
                    "file_off": file_off,
                }


def parse_dns(payload):
    if len(payload) < 12:
        return None

    tid, flags, qdcount, ancount, nscount, arcount = struct.unpack_from("!HHHHHH", payload, 0)
    qr = "response" if flags & 0x8000 else "query"

    off = 12
    names = []

    def read_name(off, depth=0):
        labels = []
        jumped = False
        start_after_jump = None

        while off < len(payload) and depth < 10:
            ln = payload[off]

            if ln == 0:
                off += 1
                break

            if (ln & 0xC0) == 0xC0:
                if off + 1 >= len(payload):
                    return None, off
                ptr = ((ln & 0x3F) << 8) | payload[off + 1]
                if not jumped:
                    start_after_jump = off + 2
                jumped = True
                sub, _ = read_name(ptr, depth + 1)
                if sub:
                    labels.append(sub)
                off = start_after_jump
                break

            off += 1
            if off + ln > len(payload):
                return None, off
            labels.append(payload[off:off + ln].decode("utf-8", "replace"))
            off += ln

        return ".".join(labels), off

    for _ in range(min(qdcount, 5)):
        name, off = read_name(off)
        if not name or off + 4 > len(payload):
            break
        qtype, qclass = struct.unpack_from("!HH", payload, off)
        off += 4
        names.append(f"{name} type={qtype} class={qclass}")

    if names:
        return f"DNS {qr} id=0x{tid:04x} q={'; '.join(names)} answers={ancount}"
    return f"DNS {qr} id=0x{tid:04x} questions={qdcount} answers={ancount}"


def parse_tls_sni(payload):
    # TLS record: type 22 handshake, version, length
    if len(payload) < 9:
        return None
    if payload[0] != 22:
        return None

    rec_len = int.from_bytes(payload[3:5], "big")
    if rec_len + 5 > len(payload):
        rec_len = len(payload) - 5

    hs = payload[5:5 + rec_len]
    if len(hs) < 42 or hs[0] != 1:
        return None

    off = 4
    off += 2      # client version
    off += 32     # random

    if off >= len(hs):
        return None
    sid_len = hs[off]
    off += 1 + sid_len

    if off + 2 > len(hs):
        return None
    cs_len = int.from_bytes(hs[off:off + 2], "big")
    off += 2 + cs_len

    if off >= len(hs):
        return None
    comp_len = hs[off]
    off += 1 + comp_len

    if off + 2 > len(hs):
        return None
    ext_total = int.from_bytes(hs[off:off + 2], "big")
    off += 2
    end = min(len(hs), off + ext_total)

    while off + 4 <= end:
        etype = int.from_bytes(hs[off:off + 2], "big")
        elen = int.from_bytes(hs[off + 2:off + 4], "big")
        off += 4
        edata = hs[off:off + elen]

        if etype == 0 and len(edata) >= 5:
            list_len = int.from_bytes(edata[0:2], "big")
            p = 2
            while p + 3 <= len(edata):
                name_type = edata[p]
                name_len = int.from_bytes(edata[p + 1:p + 3], "big")
                p += 3
                if name_type == 0 and p + name_len <= len(edata):
                    return edata[p:p + name_len].decode("utf-8", "replace")
                p += name_len

        off += elen

    return None


def app_hint(l4_proto, sport, dport, payload):
    if not payload:
        return None

    if l4_proto == "UDP" and (sport == 53 or dport == 53):
        return parse_dns(payload)

    if l4_proto == "TCP" and (sport == 53 or dport == 53):
        if len(payload) > 2:
            dns_len = int.from_bytes(payload[:2], "big")
            return parse_dns(payload[2:2 + dns_len])

    # HTTP cleartext quick preview
    starts = [
        b"GET ", b"POST ", b"PUT ", b"DELETE ", b"HEAD ", b"OPTIONS ",
        b"PATCH ", b"CONNECT ", b"TRACE ", b"HTTP/1.", b"HTTP/2"
    ]
    if any(payload.startswith(x) for x in starts) or sport in (80, 8080, 8000) or dport in (80, 8080, 8000):
        line = payload.split(b"\r\n", 1)[0]
        try:
            return "HTTP " + line.decode("utf-8", "replace")
        except Exception:
            return "HTTP payload"

    # TLS SNI
    if sport in (443, 8443) or dport in (443, 8443):
        sni = parse_tls_sni(payload)
        if sni:
            return f"TLS ClientHello SNI={sni}"
        if payload and payload[0] in (20, 21, 22, 23):
            return "TLS/SSL record"

    return None


def dissect_l3(pkt, ethertype):
    if ethertype == 0x0800:
        return dissect_ipv4(pkt)
    if ethertype == 0x86DD:
        return dissect_ipv6(pkt)
    if ethertype == 0x0806:
        return {"net": "ARP", "l4": None, "payload": b""}
    return {"net": f"Ethertype 0x{ethertype:04x}", "l4": None, "payload": pkt}


def dissect_ipv4(pkt):
    if len(pkt) < 20:
        return {"net": "IPv4 truncated", "l4": None, "payload": b""}

    ver_ihl = pkt[0]
    ver = ver_ihl >> 4
    ihl = (ver_ihl & 0x0F) * 4
    if ver != 4 or ihl < 20 or len(pkt) < ihl:
        return {"net": "IPv4 malformed", "l4": None, "payload": b""}

    total_len = int.from_bytes(pkt[2:4], "big")
    ident = int.from_bytes(pkt[4:6], "big")
    frag = int.from_bytes(pkt[6:8], "big")
    ttl = pkt[8]
    proto = pkt[9]
    src = ip4_addr(pkt[12:16])
    dst = ip4_addr(pkt[16:20])

    effective_len = min(total_len, len(pkt)) if total_len else len(pkt)
    payload = pkt[ihl:effective_len]

    flags = frag >> 13
    frag_off = frag & 0x1FFF
    frag_text = ""
    if flags or frag_off:
        frag_text = f" flags=0x{flags:x} frag_offset={frag_off}"

    net = f"IPv4 {src} -> {dst} proto={PROTO.get(proto, proto)} ttl={ttl} id=0x{ident:04x} len={total_len}{frag_text}"

    if frag_off != 0:
        return {"net": net, "l4": "fragment continuation", "payload": payload}

    return dissect_transport(net, proto, payload, src, dst)


def dissect_ipv6(pkt):
    if len(pkt) < 40:
        return {"net": "IPv6 truncated", "l4": None, "payload": b""}

    ver = pkt[0] >> 4
    if ver != 6:
        return {"net": "IPv6 malformed", "l4": None, "payload": b""}

    payload_len = int.from_bytes(pkt[4:6], "big")
    nh = pkt[6]
    hop = pkt[7]
    src = ip6_addr(pkt[8:24])
    dst = ip6_addr(pkt[24:40])
    off = 40

    # Basic extension header skipping.
    ext_chain = []
    while nh in (0, 43, 44, 50, 51, 60) and off + 2 <= len(pkt):
        ext_chain.append(PROTO.get(nh, nh))
        if nh == 44:  # Fragment header
            if off + 8 > len(pkt):
                break
            nh = pkt[off]
            off += 8
            break
        if nh == 50:  # ESP cannot parse safely
            break
        hdr_len = (pkt[off + 1] + 1) * 8
        nh = pkt[off]
        off += hdr_len

    payload = pkt[off:]
    net = f"IPv6 {src} -> {dst} next={PROTO.get(nh, nh)} hop={hop} payload_len={payload_len}"
    if ext_chain:
        net += f" ext={','.join(map(str, ext_chain))}"

    return dissect_transport(net, nh, payload, src, dst)


def tcp_flags_text(flags):
    names = []
    for bit, name in [
        (0x01, "FIN"),
        (0x02, "SYN"),
        (0x04, "RST"),
        (0x08, "PSH"),
        (0x10, "ACK"),
        (0x20, "URG"),
        (0x40, "ECE"),
        (0x80, "CWR"),
    ]:
        if flags & bit:
            names.append(name)
    return ",".join(names) if names else "none"


def dissect_transport(net, proto, payload, src, dst):
    pname = PROTO.get(proto, str(proto))

    if proto == 6:
        if len(payload) < 20:
            return {"net": net, "l4": "TCP truncated", "payload": b""}
        sport = int.from_bytes(payload[0:2], "big")
        dport = int.from_bytes(payload[2:4], "big")
        seq = int.from_bytes(payload[4:8], "big")
        ack = int.from_bytes(payload[8:12], "big")
        doff = (payload[12] >> 4) * 4
        flags = payload[13]
        win = int.from_bytes(payload[14:16], "big")
        tcp_payload = payload[doff:] if doff <= len(payload) else b""
        l4 = f"TCP {sport} -> {dport} flags={tcp_flags_text(flags)} seq={seq} ack={ack} win={win} payload_len={len(tcp_payload)}"
        hint = app_hint("TCP", sport, dport, tcp_payload)
        return {"net": net, "l4": l4, "payload": tcp_payload, "app": hint}

    if proto == 17:
        if len(payload) < 8:
            return {"net": net, "l4": "UDP truncated", "payload": b""}
        sport = int.from_bytes(payload[0:2], "big")
        dport = int.from_bytes(payload[2:4], "big")
        length = int.from_bytes(payload[4:6], "big")
        udp_payload = payload[8:]
        l4 = f"UDP {sport} -> {dport} len={length} payload_len={len(udp_payload)}"
        hint = app_hint("UDP", sport, dport, udp_payload)
        return {"net": net, "l4": l4, "payload": udp_payload, "app": hint}

    if proto == 1:
        if len(payload) >= 4:
            return {
                "net": net,
                "l4": f"ICMP type={payload[0]} code={payload[1]}",
                "payload": payload[4:],
            }
        return {"net": net, "l4": "ICMP truncated", "payload": b""}

    if proto == 58:
        if len(payload) >= 4:
            return {
                "net": net,
                "l4": f"ICMPv6 type={payload[0]} code={payload[1]}",
                "payload": payload[4:],
            }
        return {"net": net, "l4": "ICMPv6 truncated", "payload": b""}

    return {"net": net, "l4": pname, "payload": payload}


def dissect_packet(pkt, linktype):
    link = f"LINKTYPE {linktype}"
    l3 = None

    if linktype == LINKTYPE_ETHERNET:
        if len(pkt) < 14:
            return {"link": "Ethernet truncated", "net": None, "l4": None, "payload": b""}

        dst = mac_addr(pkt[0:6])
        src = mac_addr(pkt[6:12])
        ethertype = int.from_bytes(pkt[12:14], "big")
        off = 14
        vlans = []

        while ethertype in (0x8100, 0x88A8, 0x9100) and off + 4 <= len(pkt):
            tci = int.from_bytes(pkt[off:off + 2], "big")
            vlans.append(tci & 0x0FFF)
            ethertype = int.from_bytes(pkt[off + 2:off + 4], "big")
            off += 4

        link = f"Ethernet {src} -> {dst} ethertype=0x{ethertype:04x}"
        if vlans:
            link += f" vlan={','.join(map(str, vlans))}"

        l3 = dissect_l3(pkt[off:], ethertype)

    elif linktype == LINKTYPE_LINUX_SLL:
        if len(pkt) < 16:
            return {"link": "Linux SLL truncated", "net": None, "l4": None, "payload": b""}
        proto = int.from_bytes(pkt[14:16], "big")
        link = f"Linux cooked SLL proto=0x{proto:04x}"
        l3 = dissect_l3(pkt[16:], proto)

    elif linktype == LINKTYPE_LINUX_SLL2:
        if len(pkt) < 20:
            return {"link": "Linux SLL2 truncated", "net": None, "l4": None, "payload": b""}
        proto = int.from_bytes(pkt[0:2], "big")
        if_index = int.from_bytes(pkt[4:8], "big")
        link = f"Linux cooked SLL2 if_index={if_index} proto=0x{proto:04x}"
        l3 = dissect_l3(pkt[20:], proto)

    else:
        return {
            "link": f"Unsupported linktype={linktype}",
            "net": None,
            "l4": None,
            "payload": pkt,
            "app": None,
        }

    return {
        "link": link,
        "net": l3.get("net"),
        "l4": l3.get("l4"),
        "payload": l3.get("payload", b""),
        "app": l3.get("app"),
    }


def write_text(reader, out, max_packets=None, hex_preview_len=96):
    out.write(f"# pcapng_quickdump\n")
    out.write(f"# source: {reader.path}\n")
    out.write(f"# size_bytes: {os.path.getsize(reader.path)}\n")
    out.write(f"# note: standalone quick triage; no Wireshark/tshark used\n\n")

    count = 0

    for pktinfo in reader.read_packets():
        count += 1
        if max_packets and count > max_packets:
            break

        iface = pktinfo["iface"]
        linktype = iface.get("linktype")
        name = iface.get("name") or ""
        data = pktinfo["data"]
        d = dissect_packet(data, linktype)

        out.write("=" * 88 + "\n")
        out.write(
            f"Frame {pktinfo['frame']} "
            f"time={fmt_ts(pktinfo['ts'])} "
            f"caplen={pktinfo['caplen']} origlen={pktinfo['origlen']} "
            f"iface={pktinfo['iface_id']} {name} "
            f"file_offset={pktinfo['file_off']}\n"
        )

        out.write(f"Link: {d.get('link')}\n")
        if d.get("net"):
            out.write(f"Network: {d.get('net')}\n")
        if d.get("l4"):
            out.write(f"Transport: {d.get('l4')}\n")
        if d.get("app"):
            out.write(f"Application: {d.get('app')}\n")

        payload = d.get("payload") or b""
        if payload:
            hp, ap = hexdump_preview(payload, hex_preview_len)
            out.write(f"PayloadASCII: {safe_ascii(payload)}\n")
            out.write(f"PayloadHEX: {hp}\n")
            out.write(f"PayloadPreview: {ap}\n")

        out.write("\n")

    out.write(f"# packets_written: {min(count, max_packets) if max_packets else count}\n")


def main():
    ap = argparse.ArgumentParser(description="Standalone PCAPNG quick text dissector")
    ap.add_argument("input", help="Input .pcapng file")
    ap.add_argument("-o", "--output", help="Output .txt file. Default: stdout")
    ap.add_argument("--max-packets", type=int, default=None, help="Limit packet count")
    ap.add_argument("--hex-preview-len", type=int, default=96, help="Payload hex preview bytes")
    args = ap.parse_args()

    reader = PcapngReader(args.input)

    if args.output:
        with open(args.output, "w", encoding="utf-8", newline="\n") as f:
            write_text(reader, f, args.max_packets, args.hex_preview_len)
    else:
        write_text(reader, sys.stdout, args.max_packets, args.hex_preview_len)


if __name__ == "__main__":
    main()
