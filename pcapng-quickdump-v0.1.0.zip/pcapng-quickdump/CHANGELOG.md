# Changelog

## 0.1.0 - 2026-05-29

- Initial Python-only version.
- Direct PCAPNG parsing without Wireshark, TShark, libpcap, or third-party packages.
- Ethernet, Linux cooked SLL/SLL2, IPv4, IPv6, TCP, UDP, ICMP, ICMPv6 support.
- DNS, HTTP, and TLS/SNI lightweight hints.
- Upload-friendly detailed frame text output.
