# Contributing

This repository is currently in early triage-tool stage.

Near-term focus areas:

1. Detailed frame output refinements
2. Endpoint and port statistics
3. DNS / HTTP / TLS / signage hints
4. Flow summaries
5. Filtering options

Please avoid committing packet captures or generated trace dumps unless they are sanitized and intentionally included as test fixtures.
