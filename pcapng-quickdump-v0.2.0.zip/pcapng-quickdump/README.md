# pcapng-quickdump

Standalone PCAPNG-to-text quick packet dissector and report generator written in pure Python.

This project is designed for fast packet-trace triage when you want upload-friendly `.txt` outputs from a `.pcapng` file without using Wireshark, TShark, libpcap, or third-party Python packages.

## Features

- Pure Python standard library only
- Reads PCAPNG files directly
- Detailed frame output
- Flow summary output
- Endpoint and port statistics
- DNS / HTTP / TLS / signage application-hint report
- Supports Ethernet, Linux cooked SLL/SLL2, IPv4, IPv6, TCP, UDP, ICMP, ICMPv6, and ARP labeling

## Requirements

- Python 3.9 or newer recommended
- No external Python packages required

## Quick start: generate all four upload-friendly files

```powershell
python .\pcapng_quickdump.py .	race.pcapng --all-reports
```

For an input named `trace.pcapng`, this creates:

```text
trace_quickdump.txt              # detailed frames
trace_quickdump_summary.txt      # flow summary
trace_quickdump_hosts.txt        # endpoint/port stats
trace_quickdump_apps.txt         # DNS/HTTP/TLS/signage hints
```

## Individual report modes

Detailed frames only, backward-compatible with v0.1.0:

```powershell
python .\pcapng_quickdump.py .	race.pcapng -o .	race_quickdump.txt
```

Flow summary only:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --summary
```

Endpoint and port statistics only:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --top-talkers
```

DNS / HTTP / TLS / signage hints only:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --apps
```

Explicit output paths:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --all-reports `
  -o .	race_quickdump.txt `
  --summary-output .	race_quickdump_summary.txt `
  --hosts-output .	race_quickdump_hosts.txt `
  --apps-output .	race_quickdump_apps.txt
```

Limit packet count:

```powershell
python .\pcapng_quickdump.py .	race.pcapng --all-reports --max-packets 5000
```

Increase payload preview length:

```powershell
python .\pcapng_quickdump.py .	race.pcapng -o .	race_quickdump.txt --hex-preview-len 128
```

## Output files

### `trace_quickdump.txt`

Detailed per-frame text with timestamp, interface, file offset, L2/L3/L4 details, application hint, and payload ASCII/HEX preview.

### `trace_quickdump_summary.txt`

Flow summary grouped by protocol, source IP/port, destination IP/port, packets, bytes, payload bytes, frame range, duration, app hints, and TCP flag counts.

### `trace_quickdump_hosts.txt`

Endpoint and port statistics including protocol counts, top hosts by total bytes, top host:port endpoints, top ports, and top conversations.

### `trace_quickdump_apps.txt`

Application-oriented hints for DNS, HTTP, TLS/SNI, TLS records, and readable signage/control payloads.

## Limitations

This tool is for quick triage, not full Wireshark parity.

Known limitations:

- No TCP stream reassembly
- No IP fragment reassembly
- No decompression
- No TLS decryption
- Limited protocol decoding
- PCAPNG only; classic `.pcap` support is not currently implemented

## Security and privacy note

Packet captures can contain sensitive information including internal IP addresses, hostnames, URLs, tokens, cookies, payloads, and user data. Review generated text before sharing externally.

## Suggested GitHub workflow

```bash
git init
git add .
git commit -m "Add summary, top talkers, and app hint reports"
```

## License

MIT License. See [LICENSE](LICENSE).
