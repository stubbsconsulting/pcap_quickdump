#!/usr/bin/env python3
"""
pcapng_quickdump.py

Standalone PCAPNG-to-text quick dissector and report generator.
No Wireshark, no TShark, no libpcap, no third-party Python packages.

Reports:
  trace_quickdump.txt          detailed frames
  trace_quickdump_summary.txt  flow summary
  trace_quickdump_hosts.txt    endpoint/port stats
  trace_quickdump_apps.txt     DNS/HTTP/TLS/signage hints
"""

import argparse
import datetime as dt
import ipaddress
import os
import re
import struct
import sys
from collections import Counter, defaultdict

SHB = 0x0A0D0D0A
IDB = 0x00000001
SPB = 0x00000003
EPB = 0x00000006

LINKTYPE_ETHERNET = 1
LINKTYPE_LINUX_SLL = 113
LINKTYPE_LINUX_SLL2 = 276

PROTO = {
    1: "ICMP", 2: "IGMP", 6: "TCP", 17: "UDP", 41: "IPv6",
    47: "GRE", 50: "ESP", 51: "AH", 58: "ICMPv6", 89: "OSPF",
}


def u16(data, off, endian):
    return struct.unpack_from(endian + "H", data, off)[0]


def u32(data, off, endian):
    return struct.unpack_from(endian + "I", data, off)[0]


def mac_addr(b):
    return ":".join(f"{x:02x}" for x in b)


def ip4_addr(b):
    return ".".join(str(x) for x in b)


def ip6_addr(b):
    return str(ipaddress.IPv6Address(b))


def fmt_ts(ts_seconds):
    if ts_seconds is None:
        return "n/a"
    try:
        return dt.datetime.fromtimestamp(ts_seconds, tz=dt.timezone.utc).isoformat()
    except Exception:
        return f"{ts_seconds:.6f}"


def safe_ascii(data, max_len=160):
    b = data[:max_len]
    s = "".join(chr(x) if 32 <= x <= 126 else "." for x in b)
    if len(data) > max_len:
        s += f"... +{len(data) - max_len} bytes"
    return s


def hexdump_preview(data, max_len=96):
    b = data[:max_len]
    hex_part = " ".join(f"{x:02x}" for x in b)
    ascii_part = "".join(chr(x) if 32 <= x <= 126 else "." for x in b)
    suffix = "" if len(data) <= max_len else f" ... +{len(data) - max_len} bytes"
    return hex_part, ascii_part + suffix


def parse_options(body, off, endian):
    opts = {}
    while off + 4 <= len(body):
        code = u16(body, off, endian)
        length = u16(body, off + 2, endian)
        off += 4
        if code == 0:
            break
        value = body[off:off + length]
        opts.setdefault(code, []).append(value)
        off += (length + 3) & ~3
    return opts


def parse_if_tsresol(opts):
    resol = 1e-6
    vals = opts.get(9)
    if vals and vals[0]:
        v = vals[0][0]
        resol = 2 ** -(v & 0x7F) if v & 0x80 else 10 ** -v
    return resol


class PcapngReader:
    def __init__(self, path):
        self.path = path
        with open(path, "rb") as f:
            self.data = f.read()
        self.off = 0
        self.endian = "<"
        self.interfaces = []

    def _choose_shb(self):
        if self.off + 12 > len(self.data):
            return None
        len_le = struct.unpack_from("<I", self.data, self.off + 4)[0]
        len_be = struct.unpack_from(">I", self.data, self.off + 4)[0]
        for endian, blen in (("<", len_le), (">", len_be)):
            if blen >= 28 and self.off + blen <= len(self.data):
                magic = struct.unpack_from(endian + "I", self.data, self.off + 8)[0]
                if magic == 0x1A2B3C4D:
                    return endian, blen
        return None

    def blocks(self):
        while self.off + 12 <= len(self.data):
            raw_type_le = struct.unpack_from("<I", self.data, self.off)[0]
            if raw_type_le == SHB:
                chosen = self._choose_shb()
                if not chosen:
                    raise ValueError(f"Invalid Section Header Block at offset {self.off}")
                self.endian, blen = chosen
                btype = SHB
            else:
                btype = u32(self.data, self.off, self.endian)
                blen = u32(self.data, self.off + 4, self.endian)
            if blen < 12 or self.off + blen > len(self.data):
                raise ValueError(f"Invalid block length {blen} at file offset {self.off}")
            body = self.data[self.off + 8:self.off + blen - 4]
            cur_off = self.off
            self.off += blen
            yield btype, body, cur_off, blen

    def read_packets(self):
        frame_no = 0
        for btype, body, file_off, blen in self.blocks():
            if btype == SHB:
                self.interfaces = []
                continue
            if btype == IDB:
                if len(body) < 8:
                    continue
                opts = parse_options(body, 8, self.endian)
                name = ""
                if 2 in opts:
                    name = opts[2][0].decode("utf-8", "replace").rstrip("\x00")
                self.interfaces.append({
                    "linktype": u16(body, 0, self.endian),
                    "snaplen": u32(body, 4, self.endian),
                    "tsresol": parse_if_tsresol(opts),
                    "name": name,
                })
                continue
            if btype == EPB:
                if len(body) < 20:
                    continue
                iface_id = u32(body, 0, self.endian)
                ts_hi = u32(body, 4, self.endian)
                ts_lo = u32(body, 8, self.endian)
                caplen = u32(body, 12, self.endian)
                origlen = u32(body, 16, self.endian)
                pkt = body[20:20 + caplen]
                iface = self.interfaces[iface_id] if iface_id < len(self.interfaces) else {
                    "linktype": LINKTYPE_ETHERNET, "tsresol": 1e-6, "name": "", "snaplen": 0,
                }
                ticks = (ts_hi << 32) | ts_lo
                frame_no += 1
                yield {
                    "frame": frame_no, "ts": ticks * iface.get("tsresol", 1e-6),
                    "iface_id": iface_id, "iface": iface, "caplen": caplen,
                    "origlen": origlen, "data": pkt, "file_off": file_off,
                }
            elif btype == SPB:
                if len(body) < 4:
                    continue
                origlen = u32(body, 0, self.endian)
                pkt = body[4:4 + origlen]
                iface = self.interfaces[0] if self.interfaces else {
                    "linktype": LINKTYPE_ETHERNET, "tsresol": 1e-6, "name": "", "snaplen": 0,
                }
                frame_no += 1
                yield {
                    "frame": frame_no, "ts": None, "iface_id": 0, "iface": iface,
                    "caplen": len(pkt), "origlen": origlen, "data": pkt, "file_off": file_off,
                }


def parse_dns(payload):
    if len(payload) < 12:
        return None
    tid, flags, qdcount, ancount, nscount, arcount = struct.unpack_from("!HHHHHH", payload, 0)
    qr = "response" if flags & 0x8000 else "query"
    off = 12
    names = []

    def read_name(pos, depth=0):
        labels = []
        jumped = False
        after = None
        while pos < len(payload) and depth < 12:
            ln = payload[pos]
            if ln == 0:
                pos += 1
                break
            if (ln & 0xC0) == 0xC0:
                if pos + 1 >= len(payload):
                    return None, pos
                ptr = ((ln & 0x3F) << 8) | payload[pos + 1]
                if not jumped:
                    after = pos + 2
                sub, _ = read_name(ptr, depth + 1)
                if sub:
                    labels.append(sub)
                pos = after
                break
            pos += 1
            if pos + ln > len(payload):
                return None, pos
            labels.append(payload[pos:pos + ln].decode("utf-8", "replace"))
            pos += ln
        return ".".join(labels), pos

    for _ in range(min(qdcount, 5)):
        name, off = read_name(off)
        if not name or off + 4 > len(payload):
            break
        qtype, qclass = struct.unpack_from("!HH", payload, off)
        off += 4
        names.append(f"{name} type={qtype} class={qclass}")
    if names:
        return f"DNS {qr} id=0x{tid:04x} q={'; '.join(names)} answers={ancount}"
    return f"DNS {qr} id=0x{tid:04x} questions={qdcount} answers={ancount}"


def parse_tls_sni(payload):
    if len(payload) < 9 or payload[0] != 22:
        return None
    rec_len = int.from_bytes(payload[3:5], "big")
    rec_len = min(rec_len, len(payload) - 5)
    hs = payload[5:5 + rec_len]
    if len(hs) < 42 or hs[0] != 1:
        return None
    off = 4 + 2 + 32
    if off >= len(hs):
        return None
    off += 1 + hs[off]
    if off + 2 > len(hs):
        return None
    cs_len = int.from_bytes(hs[off:off + 2], "big")
    off += 2 + cs_len
    if off >= len(hs):
        return None
    off += 1 + hs[off]
    if off + 2 > len(hs):
        return None
    ext_total = int.from_bytes(hs[off:off + 2], "big")
    off += 2
    end = min(len(hs), off + ext_total)
    while off + 4 <= end:
        etype = int.from_bytes(hs[off:off + 2], "big")
        elen = int.from_bytes(hs[off + 2:off + 4], "big")
        off += 4
        edata = hs[off:off + elen]
        if etype == 0 and len(edata) >= 5:
            p = 2
            while p + 3 <= len(edata):
                name_type = edata[p]
                name_len = int.from_bytes(edata[p + 1:p + 3], "big")
                p += 3
                if name_type == 0 and p + name_len <= len(edata):
                    return edata[p:p + name_len].decode("utf-8", "replace")
                p += name_len
        off += elen
    return None


def app_hint(l4_proto, sport, dport, payload):
    if not payload:
        return None
    if l4_proto == "UDP" and (sport == 53 or dport == 53 or sport == 5353 or dport == 5353):
        return parse_dns(payload)
    if l4_proto == "TCP" and (sport == 53 or dport == 53) and len(payload) > 2:
        dns_len = int.from_bytes(payload[:2], "big")
        return parse_dns(payload[2:2 + dns_len])
    starts = [b"GET ", b"POST ", b"PUT ", b"DELETE ", b"HEAD ", b"OPTIONS ", b"PATCH ", b"CONNECT ", b"TRACE ", b"HTTP/1.", b"HTTP/2"]
    if any(payload.startswith(x) for x in starts) or sport in (80, 8080, 8000) or dport in (80, 8080, 8000):
        line = payload.split(b"\r\n", 1)[0]
        return "HTTP " + line.decode("utf-8", "replace")
    if sport in (443, 8443) or dport in (443, 8443):
        sni = parse_tls_sni(payload)
        if sni:
            return f"TLS ClientHello SNI={sni}"
        if payload[0] in (20, 21, 22, 23):
            return "TLS/SSL record"
    asc = safe_ascii(payload, 220)
    if "[Signage]" in asc or "Signage" in asc or ">>>>" in asc:
        return "SIGNAGE " + asc
    return None


def tcp_flags_text(flags):
    names = []
    for bit, name in ((1, "FIN"), (2, "SYN"), (4, "RST"), (8, "PSH"), (16, "ACK"), (32, "URG"), (64, "ECE"), (128, "CWR")):
        if flags & bit:
            names.append(name)
    return ",".join(names) if names else "none"


def base_rec():
    return {
        "link": None, "net": None, "l4": None, "app": None, "payload": b"",
        "src": None, "dst": None, "sport": None, "dport": None, "l4_proto": None,
        "ip_version": None, "tcp_flags": None, "payload_len": 0,
    }


def dissect_transport(rec, proto, payload):
    pname = PROTO.get(proto, str(proto))
    if proto == 6:
        if len(payload) < 20:
            rec["l4"] = "TCP truncated"
            return rec
        sport = int.from_bytes(payload[0:2], "big")
        dport = int.from_bytes(payload[2:4], "big")
        seq = int.from_bytes(payload[4:8], "big")
        ack = int.from_bytes(payload[8:12], "big")
        doff = (payload[12] >> 4) * 4
        flags = payload[13]
        win = int.from_bytes(payload[14:16], "big")
        tcp_payload = payload[doff:] if doff <= len(payload) else b""
        rec.update({"l4_proto": "TCP", "sport": sport, "dport": dport, "tcp_flags": tcp_flags_text(flags), "payload": tcp_payload, "payload_len": len(tcp_payload)})
        rec["l4"] = f"TCP {sport} -> {dport} flags={rec['tcp_flags']} seq={seq} ack={ack} win={win} payload_len={len(tcp_payload)}"
        rec["app"] = app_hint("TCP", sport, dport, tcp_payload)
        return rec
    if proto == 17:
        if len(payload) < 8:
            rec["l4"] = "UDP truncated"
            return rec
        sport = int.from_bytes(payload[0:2], "big")
        dport = int.from_bytes(payload[2:4], "big")
        length = int.from_bytes(payload[4:6], "big")
        udp_payload = payload[8:]
        rec.update({"l4_proto": "UDP", "sport": sport, "dport": dport, "payload": udp_payload, "payload_len": len(udp_payload)})
        rec["l4"] = f"UDP {sport} -> {dport} len={length} payload_len={len(udp_payload)}"
        rec["app"] = app_hint("UDP", sport, dport, udp_payload)
        return rec
    if proto == 1 and len(payload) >= 4:
        rec.update({"l4_proto": "ICMP", "l4": f"ICMP type={payload[0]} code={payload[1]}", "payload": payload[4:], "payload_len": len(payload[4:])})
        return rec
    if proto == 58 and len(payload) >= 4:
        rec.update({"l4_proto": "ICMPv6", "l4": f"ICMPv6 type={payload[0]} code={payload[1]}", "payload": payload[4:], "payload_len": len(payload[4:])})
        return rec
    rec.update({"l4_proto": pname, "l4": pname, "payload": payload, "payload_len": len(payload)})
    return rec


def dissect_ipv4(pkt):
    rec = base_rec()
    if len(pkt) < 20:
        rec["net"] = "IPv4 truncated"
        return rec
    ver = pkt[0] >> 4
    ihl = (pkt[0] & 0x0F) * 4
    if ver != 4 or ihl < 20 or len(pkt) < ihl:
        rec["net"] = "IPv4 malformed"
        return rec
    total_len = int.from_bytes(pkt[2:4], "big")
    ident = int.from_bytes(pkt[4:6], "big")
    frag = int.from_bytes(pkt[6:8], "big")
    ttl = pkt[8]
    proto = pkt[9]
    src = ip4_addr(pkt[12:16])
    dst = ip4_addr(pkt[16:20])
    effective = min(total_len, len(pkt)) if total_len else len(pkt)
    payload = pkt[ihl:effective]
    flags = frag >> 13
    frag_off = frag & 0x1FFF
    frag_text = f" flags=0x{flags:x} frag_offset={frag_off}" if flags or frag_off else ""
    rec.update({"ip_version": "IPv4", "src": src, "dst": dst})
    rec["net"] = f"IPv4 {src} -> {dst} proto={PROTO.get(proto, proto)} ttl={ttl} id=0x{ident:04x} len={total_len}{frag_text}"
    if frag_off:
        rec.update({"l4": "fragment continuation", "payload": payload, "payload_len": len(payload)})
        return rec
    return dissect_transport(rec, proto, payload)


def dissect_ipv6(pkt):
    rec = base_rec()
    if len(pkt) < 40:
        rec["net"] = "IPv6 truncated"
        return rec
    if pkt[0] >> 4 != 6:
        rec["net"] = "IPv6 malformed"
        return rec
    payload_len = int.from_bytes(pkt[4:6], "big")
    nh = pkt[6]
    hop = pkt[7]
    src = ip6_addr(pkt[8:24])
    dst = ip6_addr(pkt[24:40])
    off = 40
    ext_chain = []
    while nh in (0, 43, 44, 50, 51, 60) and off + 2 <= len(pkt):
        ext_chain.append(PROTO.get(nh, str(nh)))
        if nh == 44:
            if off + 8 > len(pkt):
                break
            nh = pkt[off]
            off += 8
            break
        if nh == 50:
            break
        hdr_len = (pkt[off + 1] + 1) * 8
        nh = pkt[off]
        off += hdr_len
    rec.update({"ip_version": "IPv6", "src": src, "dst": dst})
    rec["net"] = f"IPv6 {src} -> {dst} next={PROTO.get(nh, nh)} hop={hop} payload_len={payload_len}"
    if ext_chain:
        rec["net"] += f" ext={','.join(ext_chain)}"
    return dissect_transport(rec, nh, pkt[off:])


def dissect_l3(pkt, ethertype):
    if ethertype == 0x0800:
        return dissect_ipv4(pkt)
    if ethertype == 0x86DD:
        return dissect_ipv6(pkt)
    rec = base_rec()
    if ethertype == 0x0806:
        rec["net"] = "ARP"
    else:
        rec.update({"net": f"Ethertype 0x{ethertype:04x}", "payload": pkt, "payload_len": len(pkt)})
    return rec


def dissect_packet(pkt, linktype):
    if linktype == LINKTYPE_ETHERNET:
        if len(pkt) < 14:
            rec = base_rec(); rec["link"] = "Ethernet truncated"; return rec
        dst = mac_addr(pkt[0:6])
        src = mac_addr(pkt[6:12])
        ethertype = int.from_bytes(pkt[12:14], "big")
        off = 14
        vlans = []
        while ethertype in (0x8100, 0x88A8, 0x9100) and off + 4 <= len(pkt):
            tci = int.from_bytes(pkt[off:off + 2], "big")
            vlans.append(tci & 0x0FFF)
            ethertype = int.from_bytes(pkt[off + 2:off + 4], "big")
            off += 4
        rec = dissect_l3(pkt[off:], ethertype)
        rec["link"] = f"Ethernet {src} -> {dst} ethertype=0x{ethertype:04x}" + (f" vlan={','.join(map(str, vlans))}" if vlans else "")
        return rec
    if linktype == LINKTYPE_LINUX_SLL:
        if len(pkt) < 16:
            rec = base_rec(); rec["link"] = "Linux SLL truncated"; return rec
        proto = int.from_bytes(pkt[14:16], "big")
        rec = dissect_l3(pkt[16:], proto)
        rec["link"] = f"Linux cooked SLL proto=0x{proto:04x}"
        return rec
    if linktype == LINKTYPE_LINUX_SLL2:
        if len(pkt) < 20:
            rec = base_rec(); rec["link"] = "Linux SLL2 truncated"; return rec
        proto = int.from_bytes(pkt[0:2], "big")
        if_index = int.from_bytes(pkt[4:8], "big")
        rec = dissect_l3(pkt[20:], proto)
        rec["link"] = f"Linux cooked SLL2 if_index={if_index} proto=0x{proto:04x}"
        return rec
    rec = base_rec()
    rec.update({"link": f"Unsupported linktype={linktype}", "payload": pkt, "payload_len": len(pkt)})
    return rec


def iter_records(input_path, max_packets=None):
    reader = PcapngReader(input_path)
    for pktinfo in reader.read_packets():
        if max_packets and pktinfo["frame"] > max_packets:
            break
        d = dissect_packet(pktinfo["data"], pktinfo["iface"].get("linktype"))
        rec = dict(d)
        rec.update(pktinfo)
        rec["time"] = fmt_ts(pktinfo["ts"])
        yield rec


def write_detailed(input_path, out, max_packets=None, hex_preview_len=96):
    out.write("# pcapng_quickdump\n")
    out.write(f"# source: {input_path}\n")
    out.write(f"# size_bytes: {os.path.getsize(input_path)}\n")
    out.write("# note: standalone quick triage; no Wireshark/tshark used\n\n")
    count = 0
    for rec in iter_records(input_path, max_packets):
        count += 1
        iface = rec["iface"]
        name = iface.get("name") or ""
        out.write("=" * 88 + "\n")
        out.write(f"Frame {rec['frame']} time={rec['time']} caplen={rec['caplen']} origlen={rec['origlen']} iface={rec['iface_id']} {name} file_offset={rec['file_off']}\n")
        out.write(f"Link: {rec.get('link')}\n")
        if rec.get("net"):
            out.write(f"Network: {rec.get('net')}\n")
        if rec.get("l4"):
            out.write(f"Transport: {rec.get('l4')}\n")
        if rec.get("app"):
            out.write(f"Application: {rec.get('app')}\n")
        payload = rec.get("payload") or b""
        if payload:
            hp, ap = hexdump_preview(payload, hex_preview_len)
            out.write(f"PayloadASCII: {safe_ascii(payload)}\n")
            out.write(f"PayloadHEX: {hp}\n")
            out.write(f"PayloadPreview: {ap}\n")
        out.write("\n")
    out.write(f"# packets_written: {count}\n")


def duration(first, last):
    if first is None or last is None:
        return "n/a"
    return f"{max(0.0, last - first):.6f}s"


def write_flow_summary(input_path, out, max_packets=None, top_n=100):
    flows = {}
    total_packets = total_bytes = 0
    first_ts = last_ts = None
    for rec in iter_records(input_path, max_packets):
        total_packets += 1
        total_bytes += rec["origlen"]
        if rec["ts"] is not None:
            first_ts = rec["ts"] if first_ts is None else min(first_ts, rec["ts"])
            last_ts = rec["ts"] if last_ts is None else max(last_ts, rec["ts"])
        if rec.get("src") and rec.get("dst"):
            key = (rec.get("l4_proto") or "OTHER", rec["src"], rec.get("sport") or 0, rec["dst"], rec.get("dport") or 0)
        else:
            key = (rec.get("net") or rec.get("link") or "OTHER", "n/a", 0, "n/a", 0)
        f = flows.setdefault(key, {"packets": 0, "bytes": 0, "payload_bytes": 0, "first": rec["ts"], "last": rec["ts"], "first_frame": rec["frame"], "last_frame": rec["frame"], "apps": Counter(), "tcp_flags": Counter()})
        f["packets"] += 1; f["bytes"] += rec["origlen"]; f["payload_bytes"] += rec.get("payload_len") or 0; f["last_frame"] = rec["frame"]
        if rec["ts"] is not None:
            f["first"] = rec["ts"] if f["first"] is None else min(f["first"], rec["ts"])
            f["last"] = rec["ts"] if f["last"] is None else max(f["last"], rec["ts"])
        if rec.get("app"):
            f["apps"][rec["app"].split()[0].upper()] += 1
        if rec.get("tcp_flags"):
            f["tcp_flags"][rec["tcp_flags"]] += 1
    out.write("# pcapng_quickdump flow summary\n")
    out.write(f"# source: {input_path}\n# packets: {total_packets}\n# bytes: {total_bytes}\n# duration: {duration(first_ts, last_ts)}\n# flows: {len(flows)}\n\n")
    out.write("Top flows by bytes\n" + "=" * 88 + "\n")
    for i, (key, f) in enumerate(sorted(flows.items(), key=lambda kv: kv[1]["bytes"], reverse=True)[:top_n], 1):
        proto, src, sport, dst, dport = key
        apps = ",".join(f"{k}:{v}" for k, v in f["apps"].most_common(5)) or "-"
        flags = ",".join(f"{k}:{v}" for k, v in f["tcp_flags"].most_common(5)) or "-"
        out.write(f"{i:04d} {proto} {src}:{sport} -> {dst}:{dport} packets={f['packets']} bytes={f['bytes']} payload_bytes={f['payload_bytes']} frames={f['first_frame']}-{f['last_frame']} duration={duration(f['first'], f['last'])} apps={apps} tcp_flags={flags}\n")


def write_top_talkers(input_path, out, max_packets=None, top_n=100):
    hosts = defaultdict(lambda: {"tx_packets": 0, "rx_packets": 0, "tx_bytes": 0, "rx_bytes": 0})
    endpoints = Counter(); ports = Counter(); conversations = Counter(); protocols = Counter()
    total_packets = 0
    for rec in iter_records(input_path, max_packets):
        total_packets += 1
        proto = rec.get("l4_proto") or rec.get("net") or "OTHER"
        protocols[proto] += 1
        src, dst, sport, dport = rec.get("src"), rec.get("dst"), rec.get("sport"), rec.get("dport")
        if src:
            hosts[src]["tx_packets"] += 1; hosts[src]["tx_bytes"] += rec["origlen"]
        if dst:
            hosts[dst]["rx_packets"] += 1; hosts[dst]["rx_bytes"] += rec["origlen"]
        if src and sport:
            endpoints[(src, proto, sport)] += 1; ports[(proto, sport)] += 1
        if dst and dport:
            endpoints[(dst, proto, dport)] += 1; ports[(proto, dport)] += 1
        if src and dst:
            pair = tuple(sorted([(src, sport or 0), (dst, dport or 0)]))
            conversations[(proto, pair)] += rec["origlen"]
    out.write("# pcapng_quickdump endpoint and port stats\n")
    out.write(f"# source: {input_path}\n# packets: {total_packets}\n\n")
    out.write("Protocol packet counts\n" + "=" * 88 + "\n")
    for proto, count in protocols.most_common():
        out.write(f"{proto} packets={count}\n")
    out.write("\nTop hosts by total bytes\n" + "=" * 88 + "\n")
    for i, (host, h) in enumerate(sorted(hosts.items(), key=lambda kv: kv[1]["tx_bytes"] + kv[1]["rx_bytes"], reverse=True)[:top_n], 1):
        total = h["tx_bytes"] + h["rx_bytes"]
        out.write(f"{i:04d} host={host} total_bytes={total} tx_packets={h['tx_packets']} tx_bytes={h['tx_bytes']} rx_packets={h['rx_packets']} rx_bytes={h['rx_bytes']}\n")
    out.write("\nTop host:port endpoints by packet count\n" + "=" * 88 + "\n")
    for i, ((host, proto, port), count) in enumerate(endpoints.most_common(top_n), 1):
        out.write(f"{i:04d} {host}:{port}/{proto} packets={count}\n")
    out.write("\nTop ports by packet count\n" + "=" * 88 + "\n")
    for i, ((proto, port), count) in enumerate(ports.most_common(top_n), 1):
        out.write(f"{i:04d} port={port}/{proto} packets={count}\n")
    out.write("\nTop conversations by bytes\n" + "=" * 88 + "\n")
    for i, ((proto, pair), bytes_) in enumerate(conversations.most_common(top_n), 1):
        (h1, p1), (h2, p2) = pair
        out.write(f"{i:04d} {proto} {h1}:{p1} <-> {h2}:{p2} bytes={bytes_}\n")


def write_apps_report(input_path, out, max_packets=None, top_n=200):
    counts = Counter(); dns = Counter(); http = Counter(); tls = Counter(); signage = Counter(); events = []
    for rec in iter_records(input_path, max_packets):
        app = rec.get("app")
        if not app:
            continue
        cat = app.split()[0].upper()
        if cat.startswith("DNS"):
            cat = "DNS"; dns[app] += 1
        elif cat.startswith("HTTP"):
            cat = "HTTP"; http[app] += 1
        elif cat.startswith("TLS"):
            cat = "TLS"; tls[app] += 1
        elif cat.startswith("SIGNAGE"):
            cat = "SIGNAGE"; signage[safe_ascii(rec.get("payload") or b"", 220)] += 1
        counts[cat] += 1
        events.append((rec, cat, app))
    out.write("# pcapng_quickdump application hints\n")
    out.write(f"# source: {input_path}\n# app_events: {len(events)}\n\n")
    out.write("Application category counts\n" + "=" * 88 + "\n")
    for cat, count in counts.most_common():
        out.write(f"{cat} count={count}\n")
    def section(title, counter):
        out.write(f"\n{title}\n" + "=" * 88 + "\n")
        if not counter:
            out.write("none\n"); return
        for i, (item, count) in enumerate(counter.most_common(top_n), 1):
            out.write(f"{i:04d} count={count} {item}\n")
    section("DNS hints", dns); section("HTTP hints", http); section("TLS hints", tls); section("Signage/control hints", signage)
    out.write("\nChronological application events\n" + "=" * 88 + "\n")
    for rec, cat, app in events[:top_n]:
        out.write(f"Frame {rec['frame']} time={rec['time']} {rec.get('l4_proto') or 'OTHER'} {rec.get('src') or 'n/a'}:{rec.get('sport') or 0} -> {rec.get('dst') or 'n/a'}:{rec.get('dport') or 0} category={cat} detail={app}\n")


def derive_paths(input_path, output_path=None, report_dir=None):
    input_abs = os.path.abspath(input_path)
    if output_path:
        detailed = os.path.abspath(output_path)
        base_dir = os.path.dirname(detailed)
        stem = os.path.splitext(os.path.basename(detailed))[0]
    else:
        base_dir = os.path.abspath(report_dir or os.path.dirname(input_abs) or os.getcwd())
        stem = os.path.splitext(os.path.basename(input_path))[0] + "_quickdump"
        detailed = os.path.join(base_dir, stem + ".txt")
    if report_dir:
        base_dir = os.path.abspath(report_dir)
        os.makedirs(base_dir, exist_ok=True)
        detailed = os.path.join(base_dir, os.path.basename(detailed))
    return {
        "detailed": detailed,
        "summary": os.path.join(base_dir, stem + "_summary.txt"),
        "hosts": os.path.join(base_dir, stem + "_hosts.txt"),
        "apps": os.path.join(base_dir, stem + "_apps.txt"),
    }


def write_file(path, writer, *args, **kwargs):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        writer(*args, out=f, **kwargs)


def main():
    ap = argparse.ArgumentParser(description="Standalone PCAPNG quick text dissector and report generator")
    ap.add_argument("input", help="Input .pcapng file")
    ap.add_argument("-o", "--output", help="Detailed frame output .txt file. Default: stdout unless report modes are used")
    ap.add_argument("--max-packets", type=int, default=None, help="Limit packet count")
    ap.add_argument("--hex-preview-len", type=int, default=96, help="Payload hex preview bytes")
    ap.add_argument("--summary", action="store_true", help="Write flow summary report")
    ap.add_argument("--top-talkers", action="store_true", help="Write endpoint/port statistics report")
    ap.add_argument("--apps", action="store_true", help="Write DNS/HTTP/TLS/signage application-hints report")
    ap.add_argument("--all-reports", action="store_true", help="Write detailed, summary, hosts, and apps reports")
    ap.add_argument("--report-dir", help="Directory for generated report files")
    ap.add_argument("--summary-output", help="Explicit path for flow summary report")
    ap.add_argument("--hosts-output", help="Explicit path for endpoint/port stats report")
    ap.add_argument("--apps-output", help="Explicit path for application hints report")
    ap.add_argument("--top-n", type=int, default=100, help="Rows in ranked summary sections")
    args = ap.parse_args()

    report_mode = args.all_reports or args.summary or args.top_talkers or args.apps
    paths = derive_paths(args.input, args.output, args.report_dir)
    if args.summary_output: paths["summary"] = args.summary_output
    if args.hosts_output: paths["hosts"] = args.hosts_output
    if args.apps_output: paths["apps"] = args.apps_output

    if not report_mode:
        if args.output:
            with open(args.output, "w", encoding="utf-8", newline="\n") as f:
                write_detailed(args.input, f, args.max_packets, args.hex_preview_len)
        else:
            write_detailed(args.input, sys.stdout, args.max_packets, args.hex_preview_len)
        return

    generated = []
    if args.all_reports:
        with open(paths["detailed"], "w", encoding="utf-8", newline="\n") as f:
            write_detailed(args.input, f, args.max_packets, args.hex_preview_len)
        generated.append(paths["detailed"])
    if args.all_reports or args.summary:
        with open(paths["summary"], "w", encoding="utf-8", newline="\n") as f:
            write_flow_summary(args.input, f, args.max_packets, args.top_n)
        generated.append(paths["summary"])
    if args.all_reports or args.top_talkers:
        with open(paths["hosts"], "w", encoding="utf-8", newline="\n") as f:
            write_top_talkers(args.input, f, args.max_packets, args.top_n)
        generated.append(paths["hosts"])
    if args.all_reports or args.apps:
        with open(paths["apps"], "w", encoding="utf-8", newline="\n") as f:
            write_apps_report(args.input, f, args.max_packets, args.top_n)
        generated.append(paths["apps"])
    for path in generated:
        print(path)


if __name__ == "__main__":
    main()
