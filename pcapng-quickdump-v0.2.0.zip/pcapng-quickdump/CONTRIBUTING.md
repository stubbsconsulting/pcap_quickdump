# Contributing

Near-term focus areas:

1. More detailed frame output refinements
2. Filters by host, port, protocol, flow, and app hint
3. CSV and JSON report formats
4. Optional classic `.pcap` support

Please avoid committing packet captures or generated trace dumps unless they are sanitized and intentionally included as test fixtures.
