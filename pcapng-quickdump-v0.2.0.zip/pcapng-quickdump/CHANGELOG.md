# Changelog

## 0.2.0 - 2026-05-29

- Added `--summary` flow summary report.
- Added `--top-talkers` endpoint and port statistics report.
- Added `--apps` DNS/HTTP/TLS/signage application-hints report.
- Added `--all-reports` to create the standard four-file upload bundle.
- Preserved backward-compatible detailed frame output using `-o`.

## 0.1.0 - 2026-05-29

- Initial Python-only version.
- Direct PCAPNG parsing without Wireshark, TShark, libpcap, or third-party packages.
- Upload-friendly detailed frame text output.
